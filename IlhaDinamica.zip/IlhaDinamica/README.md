# Ilha Dinâmica para Android (visual iOS 27)

Overlay em Kotlin, **zero dependências externas** (só o SDK do Android). A internet só é usada para o tempo da cidade (Open-Meteo, grátis, sem chave).

## O que tem
- **Física de mola**: estica e volta como no iOS, interrompível. O loop só roda quando algo se move.
- **Música** (qualquer player): compacta (capa + equalizador) e expandida (título, controles e barra de progresso que dá para **tocar para pular**).
- **Chamada recebida**: nome/foto e botões verde (atender) e vermelho (recusar), usando as ações da própria notificação da chamada. Sem permissão extra.
- **Em chamada**: depois de atender, a ilha mostra o ícone verde e a duração; tocar volta para a chamada.
- **Timer**: anel laranja + contagem regressiva; ao acabar vibra e avisa. Deslizar para cima cancela.
- **Notificações** em fila (até 5), com foto do contato. Toque abre; deslizar para cima dispensa.
- **Carregador**: raio verde + porcentagem ao plugar.
- **Siri estilo iOS 27**: orbe + brilho + "Pesquisar ou perguntar". Segure a pílula; tocar abre o assistente real.
- **Apps silenciados** (lista para bloquear notificações de apps barulhentos) e **botão nas Configurações rápidas** para ligar/desligar.
- **Inteligente**: respeita "Não perturbe", ignora notificações silenciosas (opcional), não repete a mesma notificação e junta mensagens da mesma conversa.
- **Resiliente**: o timer sobrevive se o sistema matar o serviço e o listener de notificações se reconecta sozinho.
- **Toque preciso**: fora da Siri a janela da ilha é do tamanho da pílula (sem área morta em volta). O player expandido recolhe sozinho após 8 s sem uso.
- Painel de status no app (sobreposição, notificações, ilha ligada) e religa sozinha após atualizar o app.
- **Bateria fraca** avisa em vermelho; tempo de cada notificação ajustável (2–10 s); marcador na barra de progresso da música.
- Ícone próprio (launcher adaptativo e botão das Configurações rápidas).
- Fila de notificações mostra **+N** quando há mais esperando; timer com duração personalizada; vibração ao notificar opcional.
- Player expandido com tempo decorrido/total; **deslizar para baixo** na pílula da música expande; lista de apps silenciados com busca (silenciados aparecem primeiro).
- **Arrastar a barra** de progresso da música para pular; **deslizar para os lados** troca de faixa (player) ou dispensa o aviso (notificação/carregador).
- **Privacidade**: opção de ocultar o texto das mensagens (só remetente). **Posição horizontal** ajustável para câmeras fora do centro.
- **Econômico**: com só o equalizador/contagem rodando a animação cai para ~30 quadros/s; o botão das Configurações rápidas se atualiza sozinho.
- Notificações sem título ou só com texto longo também aparecem (usa o nome do app como título).
- **Animações**: o conteúdo sobe suavemente ao aparecer, o raio do carregador pulsa e o botão de atender chamada emite um anel.
- **Ações nas notificações**: avisos com botões (ex.: "Marcar como lida", "Arquivar") mostram uma setinha; deslize para baixo para abrir os botões e toque para executar. Respostas por texto não entram (exigem teclado).
- **Registro de erros** dentro do app (botão "Ver registro de erros" → Copiar): se algo falhar, dá para colar o erro e corrigir rápido. Falhas ao desenhar ou ler uma notificação não derrubam mais a ilha.
- Música pausada: tocar (ou deslizar para baixo) na pílula parada abre o player para dar play de novo.
- **Música + timer juntos**: com música tocando e um timer rodando, a pílula mostra a capa à esquerda e a contagem laranja à direita.
- **Cor da capa**: o player expandido ganha um brilho suave com a cor do álbum.
- **Sincronizada com o celular**: se você apagar/ler a mensagem no celular, ela some da ilha também.
- **Timer**: o aviso de "Tempo esgotado" fica 15 s; toque longo não cancela mais o timer nem a chamada sem querer (deslize para cima).
- **Timer com pausa**: toque no timer para pausar (fica cinza) e toque de novo para retomar; sobrevive se o sistema matar o serviço.
- **Mensagens seguidas**: várias mensagens da mesma conversa mostram a contagem no título, ex.: "Maria (3)".
- **Toque na capa** (player expandido) abre o app da música.
- **Tocar numa mensagem** na ilha também a remove da barra de notificações do celular (quando o app marca a notificação para sumir ao tocar).
- **Acessibilidade**: leitores de tela (TalkBack) leem o que a ilha mostra. Com "Remover animações" ativado no sistema, a ilha muda de tamanho sem animar.
- Atalho de **timer de 25 minutos** (foco) no app.
- **Carga completa**: a ilha avisa com o raio verde quando a bateria chega a 100% no carregador (uma vez por carga).
- Opção **Mostrar música** para desligar o player na ilha sem desligar o resto.
- **Silêncio por horário**: escolha um período (ex.: 23h às 7h) em que as notificações não aparecem na ilha; chamadas e timer continuam normais.
- **Troca de faixa**: ao mudar de música tocando, o player abre por 4 s mostrando o novo título (opção para desligar).
- **Fio de progresso** bem fino na base da pílula da música, na cor da capa; vibração leve ao ligar o carregador.
- **Vários players**: se um app de música pausa e outro começa a tocar (ex.: Spotify → YouTube), a ilha troca sozinha para o que está tocando; enquanto o atual toca, ela não fica pulando.
- **Bluetooth**: ao conectar fone, caixa ou relógio, a ilha avisa com o nome do aparelho (o app pede a permissão de Bluetooth só para ler o nome; sem ela aparece "Dispositivo Bluetooth"). Opção para desligar.
- **Silencioso / vibrar / toque** e **Não perturbe**: a ilha avisa rapidamente quando o modo muda (opção para desligar). Ao iniciar, ela não avisa o estado que já estava.
- Botões de **teste** para Bluetooth, Silencioso e Não perturbe (dá para ver o visual sem precisar do aparelho).
- **Silenciar app na hora**: deslize para baixo em qualquer notificação da ilha e toque em "Silenciar app" (desfaz em "Apps silenciados"). Por isso toda notificação agora mostra a setinha de ações.
- Players que só informam o "título de exibição" (alguns apps de podcast/vídeo) agora também aparecem.
- Aparece também na horizontal (ver v6.22); opção experimental de esconder em tela cheia; opção de iniciar com o celular.

## Fica ligada para sempre (v3.8)
- **Vigia** a cada ~15 min religa a ilha se o sistema a matar (só se você a deixou ligada).
- O acesso às notificações também religa a ilha ao reconectar.
- **Inicia com o celular** agora vem ligado por padrão.
- Botão **4 · bateria**: tira o app da otimização de bateria (essencial na Samsung).
- **Leve (v3.9):** avisos de **modo avião** e **fone com fio** reaproveitam o mesmo receptor de eventos (sem timers nem consulta repetida, zero custo de bateria). Opção para desligar.
- **Revisão (v4.0):** corrigido o aviso de fone que podia falhar no primeiro uso, receptor de boot fechado para outros apps, workflow não roda mais em loop ao criar a release, botão de teste do modo avião.
- Botão nas Configurações rápidas: **Foco 25 min** (um toque inicia, de novo cancela; fica aceso enquanto roda).

## Novidades da v4.3
- **Copiar código de verificação**: SMS/app com "código", "token", "senha"… e um número de 4 a 8 dígitos ganham o botão **Copiar 123456** (deslize para baixo no aviso). A cópia é marcada como sensível (Android 13+ esconde na prévia). Com "Ocultar texto" ligado o botão vira só "Copiar código". Teste: botão "Código de verificação (teste)".
- **Tela apagada**: avisos comuns não ficam esperando na fila e aparecem só quando já fazem sentido; o fim do **timer** e os avisos da **API** esperam você desbloquear e aí aparecem (não se perdem mais).
- **Anti-flood**: app que posta mais de 6 avisos diferentes em 5 s é ignorado até a janela passar; a API de fora aceita no máximo 8 comandos a cada 3 s.
- **API com timer**: `am broadcast -a br.neto.ilha.TIMER -n br.neto.ilha/.ExternalReceiver --ei sec 300` e `... -a br.neto.ilha.TIMER_STOP ...`. Números aceitam `--ei` ou `--es`.
- Painel de status mostra também **Bateria ✓/✗** (otimização de bateria); o app só pede permissões que ainda faltam.

## Novidades da v6.28
- **Tempo da cidade**: no app, seção *Tempo* → *Cidade do tempo…*, digite sua cidade (ex.: Itu) e salve. A ilha mostra um cartão com a temperatura, a cidade e um emoji do tempo, ex.: "27° • Itu — Parcialmente nublado • máx 31° • mín 19°". Se a chance de chuva for alta, avisa "leve o guarda-chuva".
- **Quando aparece**: ao **desbloquear** o celular (no máximo a cada 2 h; não aparece durante foco, pausa de avisos ou chamada) e ao **tocar na pílula parada** quando não há música nem aviso recente para rever. Dá para desligar o aviso ao desbloquear em *Mostrar o tempo ao desbloquear*.
- Os dados ficam em cache por 30 min (poupa internet e bateria); sem internet, mostra o último que tinha. Botões *Ver o tempo agora* e *Tempo da cidade (teste)* no app.
- Nova permissão: **Internet** (só para o tempo).

## Novidades da v6.27
- **Perdeu o aviso? Veja de novo**: com a pílula parada (sem música), **toque** nela ou **deslize para baixo** e a ilha mostra outra vez o último aviso de app (até 15 min depois), com os mesmos botões. Se você já apagou a notificação no celular, ela não volta.
- **Música pausada some sozinha**: depois de 5 min pausada, a música/vídeo some da ilha mesmo sem você tocar fora (volta quando tocar de novo). Vale a mesma opção *Esconder música/vídeo pausado…*.

## Novidades da v6.26
- **Música/vídeo pausado some ao tocar fora**: enquanto está tocando (mesmo depois de você sair do app do vídeo), a ilha continua mostrando e com o equalizador. Quando você **pausa** e **toca em qualquer lugar fora da ilha**, ela some. Se voltar a tocar, aparece de novo sozinha. Enquanto você não tocar fora, a pílula parada continua lá para você dar play. Desligue em *Esconder música/vídeo pausado quando eu tocar fora da ilha* (seção Música).

## Novidades da v6.25
- **A ilha só desliga quando você aperta Desligar** (botão do app ou das Configurações rápidas). Se o sistema a derrubar, se você fechar o app nos apps recentes, se ela travar ou faltar memória, um **guarda-costas** (alarme) a religa em ~2 s. Além disso ele confere a cada ~5 min, e qualquer notificação que chegar também religa a ilha na hora (antes só a cada 15 min).
- **Desligar fica desligado**: depois de apertar Desligar ela não volta sozinha, nem ao reiniciar o celular nem ao atualizar o app. Para ligar de novo, use *3 · Ligar a ilha* ou o botão das Configurações rápidas.
- Limite do Android: se você for em Configurações → Apps → Ilha Dinâmica → **Forçar parada**, o sistema bloqueia tudo até você abrir o app de novo. Isso nenhum app consegue evitar. Mantenha a Bateria em "Sem restrições" (passo 4).

## Novidades da v6.24
- **Aviso do timer não some mais sozinho com a tela apagada/bloqueada**: se o timer (ou um alarme/lembrete/aviso da API) chega com o celular dormindo ou na tela de bloqueio, a ilha segura o cartão e só começa a contar os segundos quando você **desbloquear**. Assim os botões *+1 min* e *Pausa* continuam lá quando você pegar o celular. (Antes o cartão podia sumir em 15 s, antes de você ver.)
- **Som do timer não é cortado**: o aparelho fica acordado por 4 s para o som tocar inteiro.
- **Contagem final**: nos últimos 10 s o timer fica **vermelho** e os números pulsam.
- **App mais organizado**: a lista de opções virou seções recolhíveis (*Notificações*, *Música*, *Avisos do sistema*, *Foco e timer*, *Geral*). Nada mudou nos ajustes, só ficou mais fácil de achar.

## Novidades da v6.23
- **Timer na hora certa, mesmo com a tela apagada**: antes o fim do timer dependia de um relógio interno que **para quando o celular dorme** (foco de 25 min no bolso podia avisar atrasado, só quando você acordava a tela). Agora o fim é agendado como **alarme exato do sistema**, que acorda o aparelho. Vale para timer, foco, pausa, soneca e API. Pausar/retomar/cancelar ajustam o alarme; se o sistema matar o app, o alarme religa a ilha e o aviso aparece.
- **Som ao fim do timer** (opção *Tocar um som curto quando o timer acabar*, ligada por padrão): usa o volume de notificação, então respeita o modo silencioso/vibrar e o Não perturbe. Teste no botão *Timer de 10 segundos*.
- **Correção**: se o timer acabava enquanto o app estava fechado (até 10 min), o aviso aparecia, mas o foco **não era contado** e o botão *Pausa* sumia. Agora a duração original é restaurada e tudo funciona como se o app estivesse aberto.
- **Correção**: o aviso de fim não pode mais aparecer em dobro se o alarme e o relógio interno chegarem juntos.

## Novidades da v6.22
- **Funciona deitado**: a ilha agora aparece também com o celular na horizontal, no topo e centralizada (antes ela sumia). Opção *Mostrar também na horizontal (celular deitado)*, ligada por padrão; desligue para voltar a esconder. Para esconder só em vídeos em tela cheia, use *Esconder em tela cheia (experimental)*. A largura máxima dos cartões agora usa o lado menor da tela, igual em pé e deitado. Se a câmera ficar de lado, ajuste *Posição horizontal* e *Distância do topo*.

## Novidades da v6.21
- **Pausa longa**: a cada 4 focos do dia (4º, 8º…), o botão do aviso final vira *Pausa longa 15 min* (slider 0–45 min; 0 = desligada).
- **Começar a pausa sozinho** (opção, desligada por padrão): ao fim do foco a pausa já começa e o aviso diz "pausa de X min começou". Ao fim da pausa continua o botão *Foco* (o próximo foco é sempre por escolha sua).

## Novidades da v6.20
- **Apps que furam o modo foco**: botão *Apps que furam o modo foco…* (mesma lista com busca dos apps silenciados). Os apps marcados (ex.: mensagens da família) continuam aparecendo na ilha durante o foco. Entra no backup de configurações.

## Novidades da v6.19
- **Modo foco**: enquanto o timer "Foco" roda (não pausado), as notificações comuns não aparecem na ilha (chamadas, alarmes, lembretes, timer e avisos da API continuam). Elas seguem normalmente na barra de notificações do celular. Ao fim do foco, o aviso diz quantas foram seguradas, ex.: "5 avisos segurados". Desligue em *Silenciar os avisos comuns da ilha durante o foco*.

## Novidades da v6.18
- **Meta diária de focos** (slider, padrão 4; 0 = sem meta): o painel mostra "3 de 4", o cartão do timer mostra "3 de 4 focos hoje" e, ao bater a meta, o aviso final diz "meta batida!" com uma vibração extra.
- **Nome do timer no player**: com música e timer ao mesmo tempo, o player expandido mostra o nome e o tempo restante (laranja; cinza se pausado) no centro, abaixo da barra de progresso.
- Botão **Zerar histórico de focos** (pede confirmação).

## Novidades da v6.17
- **Histórico de focos**: o painel do app (seção Timer) mostra os focos de hoje, a **sequência** de dias seguidos com pelo menos 1 foco e os focos de cada um dos últimos 7 dias (guarda 2 semanas; fica só no aparelho e fora do backup).

## Novidades da v6.16
- **Nome do timer na pílula**: deslize para baixo na pílula do timer e aparece um cartão com o nome, quanto falta (ou "Pausado") e os focos de hoje; deslize de novo para ver os botões **Pausar/Retomar** e **Cancelar**.
- **Contador de focos do dia**: cada foco concluído (timer chamado "Foco", sem soneca) soma 1 e o aviso final diz, por exemplo, "Foco terminou • 3º foco de hoje". O total também aparece no app (zera na virada do dia).
- **Foco e pausa ajustáveis**: sliders *Duração do foco* (5–90 min, padrão 25) e *Duração da pausa* (1–30 min, padrão 5) no app. Valem para o botão **Iniciar foco**, o botão das Configurações rápidas (o nome acompanha, ex.: "Foco 40 min") e os botões do aviso final. Entram no backup de configurações; o contador do dia não.

## Novidades da v6.15
- **Ciclo Pomodoro completo**: o botão de foco (app e Configurações rápidas) agora é "Foco"; ao acabar, o aviso oferece **Pausa 5 min** e, ao fim da pausa, **Foco 25 min** (e +1 min), sem abrir o app.
- Botão **Timer de 10 segundos (testar o aviso final)** no app.

## Novidades da v6.14
- **Timer longo legível**: a partir de 1 hora o relógio vira `1:30:00` (antes mostrava `90:00` ou `600:00`, largo demais), com fonte menor para não encostar na câmera.
- **API de pausa**: `am broadcast -a br.neto.ilha.TIMER_TOGGLE -n br.neto.ilha/.ExternalReceiver` pausa/retoma o timer (igual ao toque na pílula). Aceita `--es key` se houver senha.
- **Acessibilidade**: o leitor de tela agora diz o nome do timer e quanto falta.

## Novidades da v6.13
- **Timer com nome pela API**: `am broadcast -a br.neto.ilha.TIMER -n br.neto.ilha/.ExternalReceiver --ei sec 600 --es label "Macarrão"`; ao acabar, o aviso diz "Macarrão terminou". O nome sobrevive à soneca e se o sistema matar o serviço.
- **Pomodoro**: depois do foco de 25 min, deslize para baixo no aviso e toque em **Pausa 5 min**.
- **Senha da API** comparada de forma segura (tempo constante).

## Novidades da v6.12
- **Intensidade do brilho colorido** ajustável (0–200%, padrão 100%): se o brilho ficar forte ou fraco demais no seu aparelho, ajuste sem precisar de nova versão. Atualiza ao soltar o controle.

## Novidades da v6.11
- **Brilho colorido em mais lugares**: além das notificações, o carregador (verde ou vermelho na bateria fraca), o timer (laranja, some quando pausado) e a duração da chamada (verde) ganham o mesmo brilho suave atrás do ícone. A opção *Brilho colorido* liga/desliga tudo junto.

## Novidades da v6.10
- **Duração da pausa ajustável**: o botão *Pausar avisos* das Configurações rápidas não é mais fixo em 1 hora; escolha de 15 min a 4 h no controle *Duração do botão "Pausar avisos"* (padrão 60 min).

## Novidades da v6.9
- **Brilho com a cor do app**: a notificação ganha um brilho suave atrás do ícone com a cor de destaque do app (verde do WhatsApp, azul do Telegram…), como o player já fazia com a capa. Apps sem cor definida ou com cor cinza/branca ficam sem brilho. Dá para desligar em *Brilho com a cor do app nas notificações*.

## Novidades da v6.8
- **Release com a versão**: o título e as notas da aba Releases mostram a versão do app (ex.: "Ilha Dinâmica v6.8"), para saber qual APK você baixou. O workflow também tem limite de 20 min, para não ficar preso.

## Novidades da v6.7
- **Backup das configurações**: *Copiar minhas configurações* gera um texto com todos os seus ajustes (posição, tamanhos, opções, apps silenciados, senha da API); *Colar configurações* restaura. Útil ao reinstalar ou trocar de celular (guarde o texto, ele inclui a senha da API se houver).

## Novidades da v6.6
- **Revisão de compilação**: corrigido um acesso que o Kotlin poderia recusar na API de progresso (`intent` pode ser nulo). Sem mudança de comportamento.

## Novidades da v6.5
- **API de limpar**: `am broadcast -a br.neto.ilha.CLEAR -n br.neto.ilha/.ExternalReceiver` tira da ilha os avisos, a fila e a atividade ao vivo (timer e chamada continuam). Aceita `--es key` se houver senha.
- **Apps silenciados**: botão **Desmarcar todos** para desfazer todos os silenciamentos de uma vez.

## Novidades da v6.4
- **Privacidade na tela de bloqueio**: com o celular bloqueado, as notificações na ilha mostram só o remetente, sem o texto (ligado por padrão; desligue em *Esconder o texto com o celular bloqueado*). Funciona junto com "Ocultar o texto das mensagens".

## Novidades da v6.3
- **Progresso pela API**: scripts mostram uma barra na pílula: `am broadcast -a br.neto.ilha.PROGRESS -n br.neto.ilha/.ExternalReceiver --es title "Build" --ei pct 40`. Com `pct 100` aparece o aviso "Concluído". Reenvie a cada menos de 2 min, senão a atividade sai sozinha. Aceita `--es key` se houver senha.
- Botão **Copiar comando de exemplo (Termux)** no app (já inclui a senha, se houver).

## Novidades da v6.2
- **Soneca no timer**: quando aparece "Tempo esgotado", deslize para baixo no aviso e toque em **+1 min** ou **+5 min** para reiniciar.
- **Timer não se perde**: se o timer acabou enquanto a ilha estava desligada (até 10 min atrás, ex.: o sistema matou o app), o aviso de fim aparece assim que ela religa.
- **Senha da API (opcional)**: o receptor de avisos de fora é aberto a qualquer app do celular. Em *Senha da API de fora*, defina uma senha e mande junto `--es key SUASENHA` em qualquer comando. Vazio = como antes.
- **Correção**: aviso barrado pelo anti-flood não ficava mais "marcado como visto" e podia nunca aparecer; agora só é marcado se de fato passou.
- **Correção**: apps silenciados pelo botão da ilha que não têm ícone de lançador agora aparecem em *Apps silenciados* (antes não dava para desfazer).
- **Painel do app**: seções com título, a lista de **Testar** vem recolhida (toque para abrir) e o status fica verde quando está tudo certo e laranja quando falta algo.

## Novidades da v6.1
- Botão **Restaurar posição e tamanhos (padrão)**: volta distância do topo, largura, posição horizontal, descida ao expandir, largura dos cartões e tempo dos avisos ao padrão com um toque (útil depois de muito ajuste).

## Novidades da v6.0
- **Mensagens em 2 linhas**: avisos com texto que não cabe em uma linha agora mostram a mensagem em até 2 linhas (o cartão cresce 16 dp), em vez de cortar com "…". Os botões de ação descem junto. Textos curtos continuam em uma linha.

## Novidades da v5.9
- **Descer ao expandir automático**: enquanto você não mexer no controle, o valor padrão é calculado pela altura real da barra de status do seu aparelho (em vez de um número fixo), então o cartão já começa logo abaixo dela.

## Novidades da v5.8
- **Largura dos cartões** ajustável (280–380 dp, padrão 350): vale para o player expandido, chamada (igual), avisos (18 dp menor) e Siri (50 dp menor). Atualiza na hora ao soltar o controle. Em telas estreitas a largura continua limitada à tela.

## Novidades da v5.7
- **Descer ao expandir** (ajustável): player expandido, avisos, chamada e Siri agora descem suavemente para ficar abaixo da barra de status (hora, Wi-Fi, bateria), em vez de cobri-la. Ajuste em **"Descer ao expandir"** (0–60 dp, padrão 28; 0 = como antes). A pílula parada não muda de lugar.

## Novidades da v5.6
- **Registro de erros com cabeçalho**: ao copiar o log, ele já traz a versão do app, a versão do Android e o modelo do aparelho, para achar o problema mais rápido.

## Novidades da v5.5
- Correção: alarmes/lembretes/chamadas perdidas com a tela apagada agora de fato esperam na fila e aparecem ao desbloquear (antes eram descartados).
- **Chamada perdida** também é aviso prioritário: fura o silêncio por horário, fica 10 s e espera você desbloquear a tela.

## Novidades da v5.4
- **Atividade ao vivo**: deslizar para os lados também esconde (como nos avisos) e o toque longo não esconde mais sem querer (use deslizar).

## Novidades da v5.3
- **Revisão geral** das últimas versões (v4.4–v5.2) e correção: atividade ao vivo que fica 2 min sem atualizar (app encerrado, conexão perdida) sai sozinha da pílula, em vez de ficar travada.

## Novidades da v5.2
- **Música + download**: com música tocando, a atividade ao vivo não some atrás do player: um fio azul fino no topo da pílula mostra o progresso (o fio da música continua embaixo).

## Novidades da v5.1
- Botão **Atividade ao vivo (teste)** no app: simula um download de 10% a 100% (~9 s) e termina com o aviso "Concluído", para você ver o visual sem precisar baixar nada.

## Novidades da v5.0
- **Tempo para carregar**: toque no raio verde (ao plugar o carregador) e a ilha mostra quanto falta para a bateria ficar cheia, ex.: "Cheia em 45 min". Só aparece se o aparelho informar a estimativa; senão o toque só fecha o aviso, como antes.

## Novidades da v4.9
- **Atividade ao vivo expandida**: deslize para baixo na pílula de progresso para ver o nome e a porcentagem em um cartão (4 s); tocar nele abre o app.

## Novidades da v4.8
- **Concluído**: quando uma atividade ao vivo (download, envio…) chega a 100%, a ilha mostra um aviso rápido "Concluído" com o nome e o ícone do app; tocar abre o app.

## Novidades da v4.7
- **Botão "Pausar avisos"** nas Configurações rápidas: por 1 hora as notificações comuns não aparecem na ilha (chamadas, timer, alarmes e lembretes continuam). Toque de novo para retomar antes. Adicione o botão editando as Configurações rápidas.

## Novidades da v4.6
- **Várias atividades ao vivo**: com 2 ou mais downloads/progressos ao mesmo tempo, a ilha mostra o que atualizou por último e, quando um termina, o outro assume a pílula em vez de sumir.

## Novidades da v4.5
- **Atividade ao vivo**: notificações com barra de progresso (downloads, envios, atualizações) viram um ícone do app + anel com a porcentagem na pílula. Toque abre o app; deslize para cima esconde. Some sozinha ao chegar em 100%. Opção para desligar. Música, timer, chamada e avisos têm prioridade sobre ela.

## Novidades da v4.4
- **Tempo de leitura inteligente**: avisos com texto longo ficam mais tempo na ilha (até 10 s); os curtos seguem o tempo que você configurou.
- **Alarmes, lembretes e eventos** (categoria alarme/lembrete/agenda) têm prioridade: furam o silêncio por horário e o filtro de importância, ficam 10 s e esperam você desbloquear a tela.

## API de avisos (v4.2): o que o iPhone não tem
Qualquer script manda aviso para a ilha. No Termux:
`am broadcast -a br.neto.ilha.SHOW -n br.neto.ilha/.ExternalReceiver --es title "Build" --es text "Pronto" --ei sec 6`
(extras: `title`, `text`, `app`, `sec` = tempo em segundos, 0-30, e `key` se você definiu senha). Dá para desligar em "Permitir avisos de fora".

## Instalar como app (sem PC, sem Android Studio)
1. Crie um repositório no GitHub e envie o **conteúdo** desta pasta (o `build.gradle.kts` fica na raiz do repo).
2. Aba **Actions** → *build-apk* roda sozinha (~3-5 min).
3. Depois, aba **Releases** → baixe `IlhaDinamica.apk` direto no celular e instale (permita "fontes desconhecidas").
4. Abra o app e siga os passos 1, 2 e 3.

## Como compilar
1. **Android Studio** (PC): abra a pasta e clique em Run.
2. **Sem PC**: suba para o GitHub; `.github/workflows/build.yml` gera o APK em *Actions → artifacts*.

## Primeiro uso
1. Passos 1, 2 e 3 no app (sobreposição, notificações, ligar).
2. Ajuste "Distância do topo" e "Largura" até a pílula cobrir o furo da câmera.
3. Samsung: Bateria do app em "Sem restrições".

## Solução de problemas
- **Não aparece nada**: confira o painel de status no topo do app (sobreposição ✓, notificações ✓, ilha ligada).
- **Para de funcionar depois de um tempo (Samsung etc.)**: Bateria do app em "Sem restrições" e tire o app de "apps em suspensão".
- **Música não aparece**: o app de música precisa mostrar a notificação de mídia; abra o player uma vez.
- **Algo deu errado**: botão "Ver registro de erros" → Copiar e cole o texto.

## Limites
- O Android não deixa apps trocarem a status bar, então tudo é overlay.
- Detecção de chamada depende de o discador publicar ações "Atender/Recusar" na notificação.
- Nenhum asset da Apple; o visual é uma aproximação em Canvas.
