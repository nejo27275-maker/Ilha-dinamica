package br.neto.ilha

import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PersistableBundle
import android.os.PowerManager
import android.os.VibrationEffect
import android.service.quicksettings.TileService
import android.os.Vibrator
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import br.neto.ilha.IslandView.Mode

class IslandService : Service(), IslandView.Host {

    companion object {
        const val ACT_SIRI = "br.neto.ilha.SIRI"
        const val ACT_NOTIF = "br.neto.ilha.NOTIF"
        const val ACT_MEDIA = "br.neto.ilha.MEDIA"
        const val ACT_CHARGE = "br.neto.ilha.CHARGE"
        const val ACT_LOW = "br.neto.ilha.LOW"
        const val ACT_CALL = "br.neto.ilha.CALL"
        const val ACT_INCALL = "br.neto.ilha.INCALL"
        const val ACT_BT = "br.neto.ilha.BT"
        const val ACT_RING = "br.neto.ilha.RING"
        const val ACT_DND = "br.neto.ilha.DND"
        const val ACT_SYS = "br.neto.ilha.SYS"
        const val ACT_LIVE = "br.neto.ilha.LIVE"
        const val ACT_CODE = "br.neto.ilha.CODE"
        const val ACT_EXT = "br.neto.ilha.SHOW"
        const val ACT_TIMER = "br.neto.ilha.TIMER"
        const val ACT_TIMER_STOP = "br.neto.ilha.TIMER_STOP"
        const val ACT_TIMER_TOGGLE = "br.neto.ilha.TIMER_TOGGLE"
        /** Disparado pelo AlarmManager na hora exata do fim do timer (acorda o aparelho dormindo). */
        const val ACT_TIMER_FIRE = "br.neto.ilha.TIMER_FIRE"
        const val ACT_PROGRESS = "br.neto.ilha.PROGRESS"
        const val ACT_CLEAR = "br.neto.ilha.CLEAR"
        const val ACT_WEATHER = "br.neto.ilha.WEATHER"
        const val ACT_RELOAD = "br.neto.ilha.RELOAD"
        @Volatile var running = false
        @Volatile var timerActive = false
        /** Foco rodando (não pausado): o listener segura os avisos comuns até o fim. */
        @Volatile var focusRunning = false
        /** Quantos avisos comuns foram segurados durante o foco atual. */
        @Volatile var focusMissed = 0

        /** PendingIntent do alarme de fim do timer (o mesmo para agendar e cancelar). */
        fun fireIntent(c: Context): PendingIntent =
            PendingIntent.getForegroundService(
                c, 9, Intent(c, IslandService::class.java).setAction(ACT_TIMER_FIRE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        /** Cancela o alarme do timer (ex.: ao desligar a ilha, para ela não ser religada sozinha). */
        fun cancelAlarm(c: Context) {
            try { c.getSystemService(AlarmManager::class.java)?.cancel(fireIntent(c)) } catch (e: Exception) {}
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: IslandView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("ilha", MODE_PRIVATE) }

    private var media: IslandBus.Media? = null
    /** Música/vídeo pausado e você tocou fora: some da ilha até voltar a tocar. */
    private var mediaHidden = false
    /** Último aviso de app mostrado (para ver de novo com um toque/deslize na pílula parada). */
    private var lastShown: IslandBus.Notif? = null
    private var lastShownAt = 0L
    private var pausedArmed = false
    /** Música/vídeo pausado há 5 min: some da ilha sozinho (volta quando tocar de novo). */
    private val endPaused = Runnable {
        pausedArmed = false
        val m = media ?: return@Runnable
        if (!m.playing && !mediaHidden && prefs.getBoolean("hidePaused", true)) {
            mediaHidden = true; setExpanded(false); refresh()
        }
    }
    private fun shownMedia(): IslandBus.Media? = if (mediaHidden) null else media
    private var notif: IslandBus.Notif? = null
    private val queue = ArrayDeque<IslandBus.Notif>()
    private var expanded = false
    private var actionsOpen = false
    private var siri = false
    private var charging = false
    private var call: IslandBus.Call? = null
    private var live: IslandBus.Live? = null
    private var liveHidden: String? = null   // atividade dispensada com o gesto (não reaparece a cada atualização)
    private var active: IslandBus.Active? = null
    private var timerEnd = 0L
    private var timerTotal = 1L
    private var timerPaused = false
    private var timerLeft = 0L
    private var timerLabel = ""   // nome opcional do timer (API: --es label "Macarrão")
    private var attached = false
    private var hiddenLandscape = false
    private var hiddenFs = false
    private var fullShown = false   // já avisou "100%" nesta carga
    private var headset = 0          // fone com fio: 0 = fora, 1 = ligado
    private var t0 = 0L              // quando o serviço iniciou (ignora o estado "grudado" do sistema)
    private var ringer = -1          // último modo de toque (silencioso/vibrar/normal)
    private var dnd = 0              // último filtro do Não perturbe

    /** Segurança: se uma atividade ao vivo fica 2 min sem atualizar (app morto, listener caiu), sai da pílula. */
    private val endLive = Runnable { live = null; liveHidden = null; refresh() }

    private val endExpand = Runnable { expanded = false; refresh() }
    private val endSiri = Runnable { siri = false; refresh() }
    private val endNotif = Runnable { nextNotif() }
    private val endCharge = Runnable { charging = false; refresh() }
    /** PendingIntent que reinicia o timer por [sec] segundos (botões de soneca do aviso "Tempo esgotado"). */
    private fun snoozeIntent(sec: Int, req: Int, label: String = timerLabel): PendingIntent =
        PendingIntent.getForegroundService(
            this, req,
            Intent(this, IslandService::class.java).setAction(ACT_TIMER).putExtra("sec", sec).putExtra("label", label),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private val endTimer = Runnable {
        if (timerEnd == 0L) return@Runnable   // já terminou (o alarme e o Handler podem chegar juntos)
        timerEnd = 0L
        disarmAlarm()
        prefs.edit().remove("timerWall").apply()
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
        } catch (e: Exception) {}
        timerSound()
        // deslize para baixo no aviso: "+1 min" / "+5 min" (soneca) reiniciam o timer;
        // depois de um foco de 25 min aparece também "Pausa 5 min"
        val acts = mutableListOf(
            IslandBus.Act("+1 min", snoozeIntent(60, 1)),
            IslandBus.Act("+5 min", snoozeIntent(300, 2))
        )
        val fMs = focoMs()
        val pMin = pausaMin()
        // foco concluído (duração original; a soneca "+1 min" não conta de novo): soma no contador do dia
        val doneFocus = timerLabel == "Foco" && timerTotal == fMs
        val nFoco = if (doneFocus) Metrics.addFocus(applicationContext) else 0
        // a cada 4 focos do dia a pausa é a longa (0 = desligada); "começar a pausa sozinho" liga a pausa sem tocar em nada
        val longMin = prefs.getInt("pausaLongMin", 15).coerceIn(0, 45)
        val isLong = nFoco > 0 && longMin > 0 && nFoco % 4 == 0
        val pEff = if (isLong) longMin else pMin
        val auto = doneFocus && prefs.getBoolean("focoAuto", false)
        if (!auto && (timerLabel.isEmpty() || timerLabel == "Foco") && timerTotal == fMs)
            acts.add(IslandBus.Act((if (isLong) "Pausa longa " else "Pausa ") + pEff + " min", snoozeIntent(pEff * 60, 3, "Pausa")))
        // fim da pausa: um toque volta ao foco (fecha o ciclo Pomodoro)
        if (timerLabel == "Pausa") { acts.removeAt(1); acts.add(IslandBus.Act("Foco ${fMs / 60_000L} min", snoozeIntent((fMs / 1000L).toInt(), 4, "Foco"))) }
        val lbl = timerLabel
        val meta = prefs.getInt("focoMeta", 4)
        val missed = if (lbl == "Foco") focusMissed else 0
        focusMissed = 0
        val msg = (if (lbl.isNotEmpty()) "$lbl terminou" else "O timer terminou") +
            (if (nFoco > 0) " • ${nFoco}º foco de hoje" else "") +
            (if (auto) " • pausa de $pEff min começou" else "") +
            (if (missed > 0) " • $missed ${if (missed == 1) "aviso" else "avisos"} segurado${if (missed == 1) "" else "s"}" else "") +
            (if (nFoco > 0 && meta > 0 && nFoco == meta) " • meta batida!" else "")
        if (nFoco > 0 && meta > 0 && nFoco == meta) {   // meta do dia: vibração extra curta
            try { getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(longArrayOf(700, 120, 120, 120), -1)) } catch (e: Exception) {}
        }
        enqueue(
            IslandBus.Notif(
                "Timer", "Tempo esgotado", msg,
                applicationContext.getDrawable(android.R.drawable.ic_lock_idle_alarm), null,
                actions = acts,
                holdMs = 15_000L, sticky = true
            )
        )
        if (auto) startTimer(pEff * 60, "Pausa")
        refresh()
    }

    /** Duração do foco e da pausa (ajustáveis no app; padrão 25 e 5 min). */
    private fun focoMs() = prefs.getInt("focoMin", 25).coerceIn(5, 90) * 60_000L
    private fun pausaMin() = prefs.getInt("pausaMin", 5).coerceIn(1, 30)

    // ---- alarme exato: o Handler conta só o tempo com o aparelho acordado; com a tela apagada no bolso o timer atrasava

    /** Agenda o fim do timer para daqui a [inMs] ms, acordando o aparelho se estiver dormindo. */
    private fun armAlarm(inMs: Long) {
        try {
            val am = getSystemService(AlarmManager::class.java) ?: return
            val at = SystemClock.elapsedRealtime() + inMs
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, fireIntent(this))
            else am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, fireIntent(this))
        } catch (e: Exception) { ErrorLog.add(this, "alarme do timer", e) }
    }

    private fun disarmAlarm() = cancelAlarm(this)

    private var tone: android.media.Ringtone? = null

    /** Som curto ao fim do timer (opção). Usa o volume de notificação: respeita silencioso e Não perturbe. */
    private fun timerSound() {
        if (!prefs.getBoolean("somTimer", true)) return
        try {
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            val r = android.media.RingtoneManager.getRingtone(applicationContext, uri) ?: return
            r.audioAttributes = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            tone?.stop()
            tone = r
            // o aparelho pode voltar a dormir logo após o alarme e cortar o som: segura-o acordado por 4 s
            getSystemService(PowerManager::class.java)
                ?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ilha:timer")?.acquire(4000L)
            r.play()
        } catch (e: Exception) { ErrorLog.add(this, "som do timer", e) }
    }

    private fun timerCmd(action: String, req: Int): PendingIntent =
        PendingIntent.getForegroundService(
            this, req, Intent(this, IslandService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Deslizar para baixo na pílula do timer: cartão com o nome, o que falta e botões Pausar/Cancelar. */
    private fun showTimerCard() {
        val left = if (timerPaused) timerLeft else (timerEnd - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        val n = Metrics.focusToday(this)
        val metaDia = prefs.getInt("focoMeta", 4)
        val deMeta = if (metaDia > 0) " de $metaDia" else ""
        val text = (if (timerPaused) "Pausado • faltam " else "Faltam ") + Metrics.clock(left) +
            (if (n > 0) " • $n$deMeta focos hoje" else "")
        enqueue(
            IslandBus.Notif(
                "Timer", timerLabel.ifEmpty { "Timer" }, text,
                applicationContext.getDrawable(android.R.drawable.ic_lock_idle_alarm), null,
                actions = listOf(
                    IslandBus.Act(if (timerPaused) "Retomar" else "Pausar", timerCmd(ACT_TIMER_TOGGLE, 5)),
                    IslandBus.Act("Cancelar", timerCmd(ACT_TIMER_STOP, 6))
                ),
                holdMs = 5000L
            )
        )
    }

    private val power = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                // tela apagou: avisos comuns saem da fila; os importantes (timer/API) esperam o desbloqueio
                Intent.ACTION_SCREEN_OFF -> {
                    queue.removeAll { !it.sticky }
                    if (notif?.sticky != true) nextNotif()
                    ui.removeCallbacks(endNotif)
                }
                Intent.ACTION_USER_PRESENT -> { resumeNotifTimer(); glanceWeather() }
                Intent.ACTION_SCREEN_ON ->
                    if (c.getSystemService(KeyguardManager::class.java)?.isKeyguardLocked != true) resumeNotifTimer()
                Intent.ACTION_POWER_CONNECTED -> if (prefs.getBoolean("charge", true)) showCharge()
                Intent.ACTION_BATTERY_LOW -> if (prefs.getBoolean("low", true)) showCharge(true)
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    val m = i.getIntExtra(AudioManager.EXTRA_RINGER_MODE, -1)
                    if (m != -1 && m != ringer) {
                        ringer = m
                        if (prefs.getBoolean("ring", true)) showRinger(m)
                    }
                }
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    val f = c.getSystemService(NotificationManager::class.java).currentInterruptionFilter
                    if (f != 0 && f != dnd) {
                        dnd = f
                        if (prefs.getBoolean("ring", true)) showDnd(f != NotificationManager.INTERRUPTION_FILTER_ALL)
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> if (prefs.getBoolean("bt", true)) showBluetooth(i)
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> if (prefs.getBoolean("sys", true)) {
                    val on = i.getBooleanExtra("state", false)
                    showSystem("Modo avião", if (on) "Ligado" else "Desligado",
                        if (on) android.R.drawable.ic_lock_airplane_mode else android.R.drawable.ic_lock_airplane_mode_off)
                }
                AudioManager.ACTION_HEADSET_PLUG -> {
                    val st = i.getIntExtra("state", 0)
                    val fresh = SystemClock.elapsedRealtime() - t0 < 1500L
                    if (st != headset && !fresh && prefs.getBoolean("sys", true))
                        showSystem("Fone de ouvido", if (st == 1) "Conectado" else "Desconectado", android.R.drawable.stat_sys_headset)
                    headset = st
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                    val pct = if (lvl < 0) 0 else lvl * 100 / sc
                    val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                    if (plugged && pct >= 100) {
                        if (!fullShown) { fullShown = true; if (prefs.getBoolean("charge", true)) showCharge() }
                    } else if (!plugged || pct < 95) fullShown = false
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        ErrorLog.install(this)
        if (Watchdog.want(this)) KeepAlive.arm(this)
        startAsForeground()
        syncTile()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = IslandView(this).also { it.host = this }
        view = v
        val d = resources.displayMetrics.density
        lp = WindowManager.LayoutParams(
            (v.idleW + 2 * v.pad).toInt(), (34 * d + 2 * v.pad).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            title = "IlhaDinamica"
        }
        applySettings()
        hiddenLandscape = landHide(resources.configuration)
        updateVisibility()

        // se já ligou com a bateria cheia no carregador, não avisa de novo ao iniciar
        registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let {
            val sc = it.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            fullShown = it.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 &&
                it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / sc >= 100
        }
        // guarda o estado atual: o sistema entrega o último estado ao registrar, e isso não é mudança
        ringer = getSystemService(AudioManager::class.java).ringerMode
        dnd = getSystemService(NotificationManager::class.java).currentInterruptionFilter
        t0 = SystemClock.elapsedRealtime()
        val f = IntentFilter(Intent.ACTION_POWER_CONNECTED).apply {
            addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(AudioManager.ACTION_HEADSET_PLUG)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(power, f)

        media = if (prefs.getBoolean("media", true)) IslandBus.media else null
        IslandBus.onMedia = { m ->
            val mm = if (prefs.getBoolean("media", true)) m else null
            val old = media
            media = mm
            if (mm == null || mm.playing) mediaHidden = false   // voltou a tocar (ou a sessão acabou): a ilha mostra de novo
            if (mm == null || mm.playing) { ui.removeCallbacks(endPaused); pausedArmed = false }
            else if (!pausedArmed) { pausedArmed = true; ui.postDelayed(endPaused, 5 * 60_000L) }
            if (mm == null) setExpanded(false)
            // trocou de faixa tocando: mostra o título por alguns segundos, como no iOS
            else if (old != null && mm.playing && old.title != mm.title && prefs.getBoolean("pop", true))
                setExpanded(true, 4000L)
            refresh()
        }
        IslandBus.onNotif = { n ->
            showNotif(n)
            if (prefs.getBoolean("notif", true) && prefs.getBoolean("vib", true)) view?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        IslandBus.onActive = { a -> active = a; refresh() }
        IslandBus.onLive = { l ->
            ui.removeCallbacks(endLive)
            if (l == null) { liveHidden = null; live = null }
            else if (l.key != liveHidden) { live = l; ui.postDelayed(endLive, 120_000L) }
            refresh()
        }
        IslandBus.onCall = { c ->
            call = c
            if (c != null) view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            refresh()
        }
        // apagou/leu a mensagem no celular: ela some da ilha também
        IslandBus.onNotifRemoved = { key ->
            queue.removeAll { it.key == key }
            if (lastShown?.key == key) lastShown = null
            if (notif?.key == key) nextNotif() else refresh()
        }
        restoreTimer()
        refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_SIRI -> startSiri()
            ACT_NOTIF -> showNotif(
                IslandBus.Notif(
                    "Ilha", "Mensagem de teste", "Assim aparece uma notificação na ilha",
                    applicationContext.getDrawable(android.R.drawable.sym_action_chat), null
                )
            )
            ACT_MEDIA -> {
                mediaHidden = false
                media = IslandBus.Media(
                    "Música de teste", "Neto", null, true,
                    200_000L, 42_000L, SystemClock.elapsedRealtime(), 1f, null
                )
                setExpanded(true)
                refresh()
            }
            ACT_CHARGE -> showCharge()
            ACT_LOW -> showCharge(true)
            ACT_CALL -> {
                call = IslandBus.Call(
                    "Maria", "Chamada recebida",
                    applicationContext.getDrawable(android.R.drawable.sym_action_call), null, null
                )
                refresh()
            }
            ACT_INCALL -> {
                active = IslandBus.Active(SystemClock.elapsedRealtime(), null)
                refresh()
            }
            ACT_BT -> enqueue(
                IslandBus.Notif(
                    "Bluetooth", "Fone de teste", "Conectado via Bluetooth",
                    applicationContext.getDrawable(android.R.drawable.stat_sys_data_bluetooth), null
                )
            )
            ACT_RING -> showRinger(AudioManager.RINGER_MODE_SILENT)
            ACT_DND -> showDnd(true)
            ACT_EXT -> enqueue(
                IslandBus.Notif(
                    intent?.getStringExtra("app") ?: "Aviso",
                    intent?.getStringExtra("title") ?: "Aviso",
                    intent?.getStringExtra("text") ?: "",
                    applicationContext.getDrawable(android.R.drawable.sym_action_chat), null,
                    holdMs = (intent?.getIntExtra("sec", 0) ?: 0) * 1000L, sticky = true
                )
            )
            ACT_CODE -> showNotif(
                IslandBus.Notif(
                    "Mensagens", "Banco", "Seu código de verificação é 482913",
                    applicationContext.getDrawable(android.R.drawable.sym_action_chat), null,
                    actions = listOf(IslandBus.Act("Copiar 482913", null, null, "482913")),
                    holdMs = 9000L
                )
            )
            ACT_LIVE -> {   // teste: progresso sobe de 10% a 100% em ~9 s e termina com "Concluído"
                val ic = applicationContext.getDrawable(android.R.drawable.stat_sys_download)
                for (i in 1..10) ui.postDelayed({
                    val f = i / 10f
                    if (f >= 1f) {
                        live = null; liveHidden = null
                        enqueue(IslandBus.Notif("Download", "Concluído", "Arquivo de teste", ic, null, holdMs = 4000L))
                    } else IslandBus.onLive?.invoke(IslandBus.Live("teste", "Arquivo de teste", ic, f, null))
                }, i * 900L)
            }
            ACT_SYS -> showSystem("Modo avião", "Ligado", android.R.drawable.ic_lock_airplane_mode)
            ACT_TIMER -> startTimer(intent?.getIntExtra("sec", 60) ?: 60, intent?.getStringExtra("label") ?: "")
            ACT_TIMER_STOP -> cancelTimer()
            ACT_WEATHER -> showWeather(true)
            ACT_TIMER_FIRE -> if (timerEnd > 0L && !timerPaused && SystemClock.elapsedRealtime() >= timerEnd - 2000L) {
                ui.removeCallbacks(endTimer); endTimer.run()   // alarme exato: termina na hora certa mesmo com o aparelho dormindo
            }
            ACT_TIMER_TOGGLE -> if (timerEnd > 0L) { toggleTimer(); refresh() }   // API: pausa/retoma o timer
            ACT_CLEAR -> {   // API: limpa avisos na fila, o aviso atual e a atividade ao vivo (timer e chamada não)
                queue.clear()
                ui.removeCallbacks(endNotif); ui.removeCallbacks(endLive)
                notif = null; actionsOpen = false; live = null; liveHidden = null
                refresh()
            }
            ACT_PROGRESS -> {   // API: scripts mostram progresso na pílula (ex.: build, backup no Termux)
                val title = intent?.getStringExtra("title") ?: "Progresso"
                val pct = (intent?.getIntExtra("pct", 0) ?: 0).coerceIn(0, 100)
                val ic = applicationContext.getDrawable(android.R.drawable.stat_sys_download)
                if (pct >= 100) {
                    ui.removeCallbacks(endLive); live = null; liveHidden = null
                    enqueue(IslandBus.Notif(title, "Concluído", title, ic, null, holdMs = 4000L, sticky = true))
                } else IslandBus.onLive?.invoke(IslandBus.Live("api:$title", title, ic, pct / 100f, null))
            }
            ACT_RELOAD -> applySettings()
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        hiddenLandscape = landHide(newConfig)
        updateVisibility()
    }

    override fun onDestroy() {
        running = false
        focusRunning = false
        syncTile()
        IslandBus.onMedia = null
        IslandBus.onNotif = null
        IslandBus.onCall = null
        IslandBus.onActive = null
        IslandBus.onLive = null
        IslandBus.onNotifRemoved = null
        try { unregisterReceiver(power) } catch (e: Exception) {}
        try { tone?.stop() } catch (e: Exception) {}
        ui.removeCallbacksAndMessages(null)
        view?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        // quem derruba a ilha (sistema, memória, "fechar tudo") não a desliga: o guarda-costas religa em 1,5 s.
        // Só não religa se foi o botão Desligar (ele limpa "want" antes de parar o serviço).
        if (Watchdog.want(this)) KeepAlive.arm(this, 1500L)
        super.onDestroy()
    }

    /** Deslizou o app para fechar nos apps recentes: a ilha continua. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (Watchdog.want(this)) KeepAlive.arm(this, 1500L)
    }

    /** Deitado: a ilha só some se a opção "Mostrar também na horizontal" for desligada (padrão: aparece). */
    private fun landHide(cfg: Configuration): Boolean =
        cfg.orientation == Configuration.ORIENTATION_LANDSCAPE && !prefs.getBoolean("land", true)

    private fun applySettings() {
        val d = resources.displayMetrics.density
        val v = view ?: return
        hiddenLandscape = landHide(resources.configuration)
        lp.y = (prefs.getInt("top", 4) * d).toInt() - v.pad + extraTop(v.heightNow())
        lp.x = (prefs.getInt("x", 0) * d).toInt()
        v.applyIdleWidth(prefs.getInt("w", 96) * d)
        if (prefs.getBoolean("fs", false)) {
            v.setOnApplyWindowInsetsListener { _, ins ->
                hiddenFs = Build.VERSION.SDK_INT >= 30 && !ins.isVisible(WindowInsets.Type.statusBars())
                updateVisibility()
                ins
            }
            v.requestApplyInsets()
        } else {
            v.setOnApplyWindowInsetsListener(null)
            hiddenFs = false
            updateVisibility()
        }
        if (v.isAttachedToWindow) try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        // "Mostrar música" ligado/desligado nas opções
        val wantMedia = prefs.getBoolean("media", true)
        if (!wantMedia && media != null) { media = null; setExpanded(false) }
        else if (wantMedia && media == null) media = IslandBus.media
        refresh()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ilha", "Ilha Dinâmica", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "ilha")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Ilha Dinâmica ativa")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ------------------------------------------------------------ estado

    /** Pede ao botão das Configurações rápidas para se repintar (ligado/desligado). */
    private fun syncTile() {
        try {
            TileService.requestListeningState(this, ComponentName(this, IslandTile::class.java))
        } catch (e: Exception) {}
    }

    private fun setExpanded(on: Boolean, ms: Long = 8000L) {
        expanded = on
        ui.removeCallbacks(endExpand)
        if (on) ui.postDelayed(endExpand, ms)
    }

    /** Qualquer interação com o player expandido adia o recolhimento automático. */
    private fun bumpExpand() {
        if (!expanded) return
        ui.removeCallbacks(endExpand)
        ui.postDelayed(endExpand, 8000)
    }

    private fun startSiri() {
        if (!prefs.getBoolean("siri", true)) return
        siri = true
        ui.removeCallbacks(endSiri)
        ui.postDelayed(endSiri, 6000)
        refresh()
    }

    private fun stopSiri() {
        ui.removeCallbacks(endSiri); siri = false
    }

    private fun openAssistant() {
        val flags = Intent.FLAG_ACTIVITY_NEW_TASK
        try {
            startActivity(Intent(Intent.ACTION_VOICE_COMMAND).addFlags(flags))
        } catch (e: Exception) {
            try { startActivity(Intent(Intent.ACTION_ASSIST).addFlags(flags)) } catch (e2: Exception) {}
        }
    }

    /** Aviso rápido de sistema (modo avião, fone com fio). */
    private fun showSystem(title: String, text: String, icon: Int) {
        enqueue(IslandBus.Notif("Sistema", title, text, applicationContext.getDrawable(icon), null))
    }

    /** Silencioso / vibrar / toque: aviso rápido ao mudar o botão de volume. */
    private fun showRinger(mode: Int) {
        val silent = mode != AudioManager.RINGER_MODE_NORMAL
        val title = when (mode) {
            AudioManager.RINGER_MODE_SILENT -> "Silencioso"
            AudioManager.RINGER_MODE_VIBRATE -> "Vibrar"
            else -> "Toque"
        }
        val icon = if (silent) android.R.drawable.ic_lock_silent_mode else android.R.drawable.ic_lock_silent_mode_off
        enqueue(
            IslandBus.Notif(
                "Som", title, if (silent) "Toque desligado" else "Toque ligado",
                applicationContext.getDrawable(icon), null
            )
        )
    }

    private fun showDnd(on: Boolean) {
        enqueue(
            IslandBus.Notif(
                "Não perturbe", "Não perturbe", if (on) "Ativado" else "Desativado",
                applicationContext.getDrawable(android.R.drawable.ic_lock_silent_mode), null
            )
        )
    }

    @Suppress("DEPRECATION")
    private fun btDevice(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    /** Fone/caixa/relógio conectou: aviso rápido (o nome aparece se a permissão de Bluetooth foi dada). */
    private fun showBluetooth(i: Intent) {
        val name = try { btDevice(i)?.name } catch (e: SecurityException) { null }
        enqueue(
            IslandBus.Notif(
                "Bluetooth", name ?: "Dispositivo Bluetooth", "Conectado via Bluetooth",
                applicationContext.getDrawable(android.R.drawable.stat_sys_data_bluetooth), null
            )
        )
    }

    /** Botão "Silenciar app" da notificação: some da ilha e da fila; desfaz em "Apps silenciados". */
    private fun muteApp(pkg: String) {
        val set = HashSet<String>(prefs.getStringSet("muted", null) ?: emptySet())
        set.add(pkg)
        prefs.edit().putStringSet("muted", set).apply()
        queue.removeAll { it.key?.contains("|$pkg|") == true }
        try { Toast.makeText(this, "App silenciado (desfaça em Apps silenciados)", Toast.LENGTH_SHORT).show() } catch (e: Exception) {}
    }

    private fun showNotif(n: IslandBus.Notif) {
        if (!prefs.getBoolean("notif", true)) return
        enqueue(n)
    }

    private fun screenOn() = getSystemService(PowerManager::class.java)?.isInteractive != false

    /** Recomeça a contagem para sumir do aviso atual (depois de a tela voltar). */
    private fun resumeNotifTimer() {
        val n = notif ?: return
        ui.removeCallbacks(endNotif)
        ui.postDelayed(endNotif, if (n.holdMs > 0L) n.holdMs else prefs.getInt("dur", 5) * 1000L)
    }

    /** Botão "Copiar 123456": copia marcando como sensível (o Android 13+ esconde o texto na prévia). */
    private fun copyText(text: String) {
        try {
            val clip = ClipData.newPlainText("código", text)
            if (Build.VERSION.SDK_INT >= 33)
                clip.description.extras = PersistableBundle().apply {
                    putBoolean("android.content.extra.IS_SENSITIVE", true)
                }
            getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
            view?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            Toast.makeText(this, "Código copiado", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { ErrorLog.add(this, "copiar código", e) }
    }

    private fun enqueue(n: IslandBus.Notif) {
        if (!n.sticky && !screenOn()) return   // tela apagada: aviso comum não vale a pena guardar
        // mesma conversa (app + título): conta quantas chegaram e substitui em vez de empilhar
        val prev = queue.firstOrNull { it.app == n.app && it.title == n.title }
        val shown = notif
        if (prev != null) n.count = prev.count + 1
        else if (shown != null && shown.app == n.app && shown.title == n.title) n.count = shown.count + 1
        queue.removeAll { it.app == n.app && it.title == n.title }
        val cur = notif
        when {
            cur == null -> present(n)
            cur.app == n.app && cur.title == n.title -> present(n)
            else -> {
                if (queue.size >= 5) queue.removeFirst()
                queue.addLast(n)
                refresh()
            }
        }
    }

    /** Tela apagada ou bloqueada: a ilha não aparece por cima da tela de bloqueio. */
    private fun hiddenNow(): Boolean =
        !screenOn() || getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true

    /** Mostra de novo o último aviso de app (até 15 min depois), para quem perdeu os 5 segundos. */
    private fun replayLast(): Boolean {
        val o = lastShown ?: return false
        if (SystemClock.elapsedRealtime() - lastShownAt > 15 * 60_000L) { lastShown = null; return false }
        enqueue(IslandBus.Notif(o.app, o.title, o.text, o.icon, o.intent, o.round, o.actions, o.key,
            maxOf(o.holdMs, 6000L), o.autoCancel, false, o.accent))
        return true
    }

    // ------------------------------------------------------------ tempo da cidade

    private var lastGlance = -1L

    private fun weatherCard(w: Weather.Now): IslandBus.Notif {
        val rain = if (w.rain >= 60) " • leve o guarda-chuva" else if (w.rain >= 30) " • chuva ${w.rain}%" else ""
        return IslandBus.Notif(
            "Tempo", "${w.temp}° • ${w.city}",
            "${Weather.describe(w.code)} • máx ${w.max}° • mín ${w.min}°$rain",
            Weather.icon(applicationContext, Weather.emoji(w.code, w.day)), null,
            holdMs = 6000L
        )
    }

    /** Mostra o tempo da cidade (usa o cache de 30 min; [force] busca de novo e avisa se não der). */
    private fun showWeather(force: Boolean = false) {
        if (!Weather.configured(this)) {
            if (force) enqueue(
                IslandBus.Notif(
                    "Tempo", "Escolha sua cidade", "No app: Tempo → Cidade do tempo…",
                    applicationContext.getDrawable(android.R.drawable.ic_menu_mylocation), null
                )
            )
            return
        }
        val cache = Weather.cached(this)
        if (cache != null && !force && Weather.fresh(cache)) { enqueue(weatherCard(cache)); return }
        val app = applicationContext
        Thread {
            val w = Weather.fetch(app)
            ui.post {
                val use = w ?: cache
                if (use != null) enqueue(weatherCard(use))
                else if (force) enqueue(
                    IslandBus.Notif(
                        "Tempo", "Sem conexão", "Não consegui buscar o tempo agora",
                        app.getDrawable(android.R.drawable.ic_menu_mylocation), null
                    )
                )
            }
        }.start()
    }

    /** Ao desbloquear, mostra o tempo (no máximo a cada 2 h; não atrapalha foco, pausa de avisos ou chamada). */
    private fun glanceWeather() {
        if (!prefs.getBoolean("weatherGlance", true) || !Weather.configured(this)) return
        if (focusRunning || PauseTile.paused(this) || call != null) return
        val now = SystemClock.elapsedRealtime()
        if (lastGlance >= 0L && now - lastGlance < 2 * 3_600_000L) return
        lastGlance = now
        ui.postDelayed({ if (notif == null && call == null) showWeather() }, 900L)   // espera o desbloqueio terminar
    }

    private fun present(n: IslandBus.Notif) {
        if (n.key != null) { lastShown = n; lastShownAt = SystemClock.elapsedRealtime() }
        notif = n
        actionsOpen = false
        ui.removeCallbacks(endNotif)
        // aviso importante (fim do timer, alarme, API) com a tela apagada/bloqueada: ninguém está vendo a ilha,
        // então a contagem para sumir só começa ao desbloquear (resumeNotifTimer). Antes o cartão do timer
        // podia sumir sozinho antes de você pegar o celular e os botões "+1 min"/"Pausa" se perdiam.
        if (!(n.sticky && hiddenNow()))
            ui.postDelayed(endNotif, if (n.holdMs > 0L) n.holdMs else prefs.getInt("dur", 5) * 1000L)
        refresh()
    }

    private fun nextNotif() {
        ui.removeCallbacks(endNotif)
        actionsOpen = false
        val nx = queue.removeFirstOrNull()
        if (nx != null) present(nx) else { notif = null; refresh() }
    }

    private fun updateVisibility() {
        val v = view ?: return
        try {
            if (hiddenLandscape && attached) { wm.removeView(v); attached = false }
            else if (!hiddenLandscape && !attached) { wm.addView(v, lp); attached = true }
        } catch (e: Exception) {}
        v.visibility = if (hiddenFs) View.INVISIBLE else View.VISIBLE
    }

    private fun startTimer(sec: Int, label: String = "") {
        timerLabel = label.take(40)
        if (timerLabel == "Foco") focusMissed = 0
        prefs.edit().putString("timerLabel", timerLabel).apply()
        timerTotal = sec.coerceAtLeast(1) * 1000L
        timerPaused = false
        timerEnd = SystemClock.elapsedRealtime() + timerTotal
        prefs.edit()
            .putLong("timerWall", System.currentTimeMillis() + timerTotal)
            .putLong("timerTotal", timerTotal)
            .remove("timerPauseLeft")
            .apply()
        ui.removeCallbacks(endTimer)
        ui.postDelayed(endTimer, timerTotal)
        armAlarm(timerTotal)
        refresh()
    }

    /** Se o sistema matou o serviço no meio de um timer, retoma de onde parou. */
    private fun restoreTimer() {
        timerLabel = prefs.getString("timerLabel", "") ?: ""
        val paused = prefs.getLong("timerPauseLeft", 0L)
        if (paused > 0L) {
            timerTotal = prefs.getLong("timerTotal", paused).coerceAtLeast(1L)
            timerLeft = paused
            timerPaused = true
            timerEnd = SystemClock.elapsedRealtime() + paused   // só marca "há timer"; parado não conta
            return
        }
        val wall = prefs.getLong("timerWall", 0L)
        if (wall <= 0L) return
        val left = wall - System.currentTimeMillis()
        if (left > 0L) {
            timerTotal = prefs.getLong("timerTotal", left).coerceAtLeast(1L)
            timerEnd = SystemClock.elapsedRealtime() + left
            ui.removeCallbacks(endTimer)
            ui.postDelayed(endTimer, left)
            armAlarm(left)
        } else {
            prefs.edit().remove("timerWall").apply()
            // o timer acabou enquanto a ilha estava desligada (até 10 min atrás): avisa agora em vez de perder
            if (-left <= 10 * 60_000L) {
                // restaura a duração original: sem isso o foco não era contado e a "Pausa" não era oferecida
                timerTotal = prefs.getLong("timerTotal", 1L).coerceAtLeast(1L)
                timerEnd = SystemClock.elapsedRealtime()
                ui.post(endTimer)
            }
        }
    }

    /** Toque no timer: pausa ou retoma (sobrevive se o sistema matar o serviço). */
    private fun toggleTimer() {
        val now = SystemClock.elapsedRealtime()
        if (timerPaused) {
            timerPaused = false
            timerEnd = now + timerLeft
            ui.removeCallbacks(endTimer)
            ui.postDelayed(endTimer, timerLeft)
            armAlarm(timerLeft)
            prefs.edit()
                .putLong("timerWall", System.currentTimeMillis() + timerLeft)
                .putLong("timerTotal", timerTotal)
                .remove("timerPauseLeft")
                .apply()
        } else {
            timerLeft = (timerEnd - now).coerceAtLeast(1L)
            timerPaused = true
            ui.removeCallbacks(endTimer)
            disarmAlarm()
            prefs.edit()
                .remove("timerWall")
                .putLong("timerTotal", timerTotal)
                .putLong("timerPauseLeft", timerLeft)
                .apply()
        }
        view?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun cancelTimer() {
        ui.removeCallbacks(endTimer)
        disarmAlarm()
        timerEnd = 0L
        timerPaused = false
        prefs.edit().remove("timerWall").remove("timerPauseLeft").apply()
        refresh()
    }

    private fun showCharge(low: Boolean = false) {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        view?.battery = if (level < 0) 0 else level * 100 / scale
        view?.batteryLow = low
        charging = true
        if (prefs.getBoolean("vib", true)) view?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        ui.removeCallbacks(endCharge)
        ui.postDelayed(endCharge, if (low) 4500 else 3000)
        refresh()
    }

    private fun refresh() {
        timerActive = timerEnd > 0L
        focusRunning = timerEnd > 0L && !timerPaused && timerLabel == "Foco"
        val v = view ?: return
        val m = shownMedia()
        v.media = m
        v.tintNotif = prefs.getBoolean("ntint", true)
        v.tintK = prefs.getInt("tintInt", 100) / 100f
        v.notif = notif
        v.queued = queue.size
        v.actionsOpen = actionsOpen && notif?.actions?.isNotEmpty() == true
        v.call = call
        v.live = live
        v.activeStart = active?.start ?: 0L
        v.timerEnd = timerEnd
        v.timerTotal = timerTotal
        v.timerPaused = timerPaused
        v.timerLeft = timerLeft
        v.timerLabel = timerLabel
        v.setMode(
            when {
                call != null -> Mode.CALL
                siri -> Mode.SIRI
                notif != null -> Mode.NOTIF
                charging -> Mode.CHARGE
                m != null && expanded -> Mode.EXPANDED
                active != null -> Mode.INCALL
                // música tocando + timer: a pílula da música mostra o timer ao lado
                timerEnd > 0L && !(m != null && m.playing) -> Mode.TIMER
                m != null && m.playing -> Mode.COMPACT
                live != null -> Mode.PROGRESS
                else -> Mode.IDLE
            }
        )
    }

    // ------------------------------------------------------------ Host

    override fun onTap(mode: Mode) {
        when (mode) {
            Mode.COMPACT -> setExpanded(true)
            Mode.EXPANDED -> setExpanded(false)
            Mode.NOTIF -> {
                try { notif?.intent?.send() } catch (e: Exception) {}
                // tocou na ilha = abriu a mensagem: tira a notificação do celular também
                val k = notif?.key
                if (notif?.autoCancel == true && k != null) IslandBus.cancel?.invoke(k)
                nextNotif(); return
            }
            Mode.SIRI -> { stopSiri(); openAssistant() }
            Mode.CHARGE -> {
                ui.removeCallbacks(endCharge); charging = false
                // toque no raio: mostra quanto falta para a bateria ficar cheia (se o aparelho informar)
                val ms = try { getSystemService(BatteryManager::class.java).computeChargeTimeRemaining() } catch (e: Exception) { -1L }
                if (ms > 60_000L && view?.batteryLow != true) {
                    val min = (ms / 60_000L).toInt()
                    val falta = if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"
                    enqueue(
                        IslandBus.Notif(
                            "Bateria", "Carregando • ${view?.battery ?: 0}%", "Cheia em $falta",
                            applicationContext.getDrawable(android.R.drawable.ic_lock_idle_charging), null, holdMs = 4000L
                        )
                    )
                }
            }
            Mode.INCALL -> { try { active?.intent?.send() } catch (e: Exception) {} }
            Mode.TIMER -> toggleTimer()
            Mode.PROGRESS -> { try { live?.intent?.send() } catch (e: Exception) {} }
            Mode.CALL -> {}
            // música pausada: a pílula parada abre o player para dar play de novo
            Mode.IDLE -> if (shownMedia() != null) setExpanded(true) else if (!replayLast()) showWeather()
        }
        refresh()
    }

    override fun onLong(mode: Mode) {
        // timer e chamada não são cancelados por um toque longo acidental (use deslizar para cima)
        if (mode == Mode.TIMER || mode == Mode.INCALL || mode == Mode.CALL || mode == Mode.PROGRESS) return
        view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (mode == Mode.IDLE || mode == Mode.COMPACT) startSiri() else onDismiss(mode)
    }

    override fun onDismiss(mode: Mode) {
        when (mode) {
            Mode.NOTIF -> { nextNotif(); return }
            Mode.SIRI -> stopSiri()
            Mode.CHARGE -> { ui.removeCallbacks(endCharge); charging = false }
            Mode.EXPANDED -> setExpanded(false)
            Mode.TIMER -> { cancelTimer(); return }
            Mode.PROGRESS -> { liveHidden = live?.key; live = null }
            else -> {}
        }
        refresh()
    }

    override fun onAction(action: Int) {
        if (action == 20) {   // toque na capa: abre o app do player
            try { media?.open?.send() } catch (e: Exception) {}
            setExpanded(false); refresh(); return
        }
        if (action >= 10) {
            val c = call
            try { (if (action == 11) c?.answer else c?.decline)?.send() } catch (e: Exception) {}
            call = null
            refresh()
            return
        }
        bumpExpand()
        val tc = media?.controller?.transportControls ?: return
        when (action) {
            0 -> tc.skipToPrevious()
            1 -> if (media?.playing == true) tc.pause() else tc.play()
            2 -> tc.skipToNext()
        }
    }

    /** Tocou fora da ilha: se a música/vídeo está pausado, ela some (volta quando tocar de novo). */
    override fun onOutside() {
        if (!prefs.getBoolean("hidePaused", true)) return
        val m = media ?: return
        if (m.playing || mediaHidden) return
        mediaHidden = true
        setExpanded(false)
        refresh()
    }

    override fun onSeek(fraction: Float) {
        bumpExpand()
        val m = media ?: return
        if (m.durationMs <= 0) return
        m.controller?.transportControls?.seekTo((fraction.coerceIn(0f, 1f) * m.durationMs).toLong())
    }

    override fun onExpandNotif() {
        if (notif == null && view?.mode == Mode.IDLE && shownMedia() == null) { if (!replayLast()) showWeather(); return }
        if (notif == null && timerEnd > 0L && view?.mode == Mode.TIMER) { showTimerCard(); return }
        val l = live
        if (notif == null && l != null) {   // atividade ao vivo: abre um cartão com nome e porcentagem
            enqueue(
                IslandBus.Notif(
                    "Ao vivo", l.title, "Em andamento • ${(l.frac * 100).toInt()}%",
                    l.icon, l.intent, holdMs = 4000L
                )
            )
            return
        }
        if (notif?.actions.isNullOrEmpty()) return
        actionsOpen = true
        ui.removeCallbacks(endNotif)
        ui.postDelayed(endNotif, 8000)   // dá tempo para escolher
        refresh()
    }

    override fun onNotifAction(index: Int) {
        val a = notif?.actions?.getOrNull(index)
        val mute = a?.mutePkg
        val cp = a?.copy
        if (mute != null) muteApp(mute)
        else if (cp != null) copyText(cp)
        else try { a?.intent?.send() } catch (e: Exception) {}
        nextNotif()
    }

    /**
     * Ao expandir (player, aviso, chamada, Siri) a janela desce suavemente até [drop] dp, para o cartão
     * não cobrir hora/ícones da barra de status. A descida acompanha a altura da ilha (36 dp = 0, 66 dp+ = tudo),
     * então anima junto com a mola, sem pulo.
     */
    private fun extraTop(hPx: Float): Int {
        val d = resources.displayMetrics.density
        val prog = ((hPx / d - 36f) / 30f).coerceIn(0f, 1f)
        return (prefs.getInt("drop", Metrics.autoDrop(this)) * d * prog).toInt()
    }

    override fun onFrame(w: Int, h: Int) {
        val v = view ?: return
        lp.width = w; lp.height = h
        lp.y = (prefs.getInt("top", 4) * resources.displayMetrics.density).toInt() - v.pad + extraTop((h - 2 * v.pad).toFloat())
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }
}
