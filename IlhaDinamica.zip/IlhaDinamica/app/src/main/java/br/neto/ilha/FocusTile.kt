package br.neto.ilha

import android.content.Intent
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Botão nas Configurações rápidas: inicia o timer de foco (25 min por padrão, ajustável no app); tocar de novo cancela. */
class FocusTile : TileService() {
    override fun onStartListening() = paint()

    override fun onClick() {
        if (!Settings.canDrawOverlays(this)) return
        val stop = IslandService.running && IslandService.timerActive
        val i = Intent(this, IslandService::class.java)
        if (stop) i.setAction(IslandService.ACT_TIMER_STOP)
        else i.setAction(IslandService.ACT_TIMER).putExtra("sec", focoMin() * 60).putExtra("label", "Foco")
        startForegroundService(i)
        if (!stop) Watchdog.setWant(this, true)
        paint(!stop)
    }

    private fun focoMin() = getSharedPreferences("ilha", MODE_PRIVATE).getInt("focoMin", 25).coerceIn(5, 90)

    private fun paint(on: Boolean = IslandService.running && IslandService.timerActive) {
        val m = focoMin()
        qsTile?.apply {
            state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Foco $m min"
            updateTile()
        }
    }
}
