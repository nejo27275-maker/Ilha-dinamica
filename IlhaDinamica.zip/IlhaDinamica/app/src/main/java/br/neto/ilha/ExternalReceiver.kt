package br.neto.ilha

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock

/**
 * API de avisos: Termux, Tasker ou qualquer app manda comandos para a ilha.
 *  - Aviso:  am broadcast -a br.neto.ilha.SHOW -n br.neto.ilha/.ExternalReceiver --es title "Build" --es text "Pronto" --ei sec 6
 *  - Timer:  am broadcast -a br.neto.ilha.TIMER -n br.neto.ilha/.ExternalReceiver --ei sec 300
 *    (opcional: --es label "Macarrão" → o aviso final diz "Macarrão terminou")
 *  - Pausar/retomar: am broadcast -a br.neto.ilha.TIMER_TOGGLE -n br.neto.ilha/.ExternalReceiver
 *  - Parar:  am broadcast -a br.neto.ilha.TIMER_STOP -n br.neto.ilha/.ExternalReceiver
 * Os números aceitam --ei ou --es. Limite de 8 comandos a cada 3 s (proteção contra apps que inundam a ilha).
 * Progresso: am broadcast -a br.neto.ilha.PROGRESS -n br.neto.ilha/.ExternalReceiver --es title "Build" --ei pct 40  (100 = Concluído; reenvie a cada <2 min)
 * Limpar:   am broadcast -a br.neto.ilha.CLEAR -n br.neto.ilha/.ExternalReceiver  (tira avisos e progresso da ilha)
 * Senha opcional (definida no app): acrescente  --es key SUASENHA  em qualquer comando.
 */
class ExternalReceiver : BroadcastReceiver() {

    private fun num(i: Intent, k: String, def: Int = 0): Int {
        val v = i.getIntExtra(k, Int.MIN_VALUE)
        if (v != Int.MIN_VALUE) return v
        return i.getStringExtra(k)?.trim()?.toIntOrNull() ?: def
    }

    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a != IslandService.ACT_EXT && a != IslandService.ACT_TIMER && a != IslandService.ACT_TIMER_STOP && a != IslandService.ACT_TIMER_TOGGLE && a != IslandService.ACT_PROGRESS && a != IslandService.ACT_CLEAR) return
        val p = c.getSharedPreferences("ilha", Context.MODE_PRIVATE)
        if (!p.getBoolean("api", true)) return
        // senha opcional: qualquer app do celular pode mandar broadcast; com senha, só quem a conhece (--es key SENHA)
        val need = p.getString("apiKey", "") ?: ""
        if (need.isNotEmpty() && !java.security.MessageDigest.isEqual((i.getStringExtra("key") ?: "").toByteArray(), need.toByteArray())) return
        val now = SystemClock.elapsedRealtime()
        if (now - winStart > 3000L) { winStart = now; winCount = 0 }
        if (++winCount > 8) return
        try {
            val s = Intent(c, IslandService::class.java).setAction(a)
            when (a) {
                IslandService.ACT_EXT -> s
                    .putExtra("app", i.getStringExtra("app") ?: "Aviso")
                    .putExtra("title", (i.getStringExtra("title") ?: "Aviso").take(80))
                    .putExtra("text", (i.getStringExtra("text") ?: "").take(200))
                    .putExtra("sec", num(i, "sec").coerceIn(0, 30))
                IslandService.ACT_PROGRESS -> s
                    .putExtra("title", (i.getStringExtra("title") ?: "Progresso").take(60))
                    .putExtra("pct", num(i, "pct").coerceIn(0, 100))
                IslandService.ACT_TIMER -> s
                    .putExtra("sec", num(i, "sec", 60).coerceIn(1, 36_000))
                    .putExtra("label", (i.getStringExtra("label") ?: "").take(40))
            }
            c.startForegroundService(s)
        } catch (e: Exception) { ErrorLog.add(c, "ExternalReceiver", e) }
    }

    private companion object {
        var winStart = 0L
        var winCount = 0
    }
}
