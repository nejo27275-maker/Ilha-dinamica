package br.neto.ilha

import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.session.MediaController

/** Ponte simples (mesmo processo) entre o listener de notificações e o serviço da ilha. */
object IslandBus {
    class Media(
        val title: String,
        val artist: String,
        val art: Bitmap?,
        val playing: Boolean,
        val durationMs: Long,
        val positionMs: Long,
        val updatedAt: Long,
        val speed: Float,
        val controller: MediaController?,
        /** Abre o app do player (toque na capa). */
        val open: PendingIntent? = null
    ) {
        val accent: Int by lazy { accentOf(art) }

        fun position(now: Long): Long {
            val p = if (playing) positionMs + ((now - updatedAt) * speed).toLong() else positionMs
            return if (durationMs > 0) p.coerceIn(0L, durationMs) else 0L
        }
    }

    /** Botão de ação da notificação (sem campo de resposta), ex.: "Marcar como lida". */
    class Act(
        val label: String,
        val intent: PendingIntent?,
        val mutePkg: String? = null,
        /** Se não for nulo, o botão copia esse texto (ex.: código de verificação). */
        val copy: String? = null
    )

    class Notif(
        val app: String,
        val title: String,
        val text: String,
        val icon: Drawable?,
        val intent: PendingIntent?,
        val round: Boolean = false,
        val actions: List<Act> = emptyList(),
        /** Chave da notificação original (para sumir da ilha quando for removida no celular). */
        val key: String? = null,
        /** Se > 0, fica na ilha por esse tempo (ms) em vez do tempo padrão. */
        val holdMs: Long = 0L,
        /** A notificação some sozinha ao tocar (então tocar na ilha também a remove do celular). */
        val autoCancel: Boolean = false,
        /** Aviso importante (timer, API): espera na fila com a tela apagada e aparece ao desbloquear. */
        val sticky: Boolean = false,
        /** Cor de destaque do app (Notification.color), já clareada; 0 = sem brilho colorido. */
        val accent: Int = 0
    ) {
        /** Quantas mensagens seguidas dessa mesma conversa já chegaram (mostra "(3)" no título). */
        var count = 1
    }

    /** Chamada em andamento: [start] em SystemClock.elapsedRealtime(). */
    class Active(val start: Long, val intent: PendingIntent?)

    class Call(
        val name: String,
        val sub: String,
        val icon: Drawable?,
        val answer: PendingIntent?,
        val decline: PendingIntent?
    )

    /** Atividade ao vivo: notificação com progresso (download, envio, corrida...). [frac] de 0 a 1. */
    class Live(val key: String, val title: String, val icon: Drawable?, val frac: Float, val intent: PendingIntent?)

    var media: Media? = null
    var onLive: ((Live?) -> Unit)? = null
    var onCall: ((Call?) -> Unit)? = null
    var onActive: ((Active?) -> Unit)? = null
    var onMedia: ((Media?) -> Unit)? = null
    var onNotif: ((Notif) -> Unit)? = null
    var onNotifRemoved: ((String) -> Unit)? = null
    /** Pede ao listener para remover a notificação original do celular. */
    var cancel: ((String) -> Unit)? = null
}

private fun accentOf(bmp: Bitmap?): Int {
    val fallback = Color.rgb(255, 55, 95)
    if (bmp == null) return fallback
    return try {
        val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.55f)
        hsv[2] = hsv[2].coerceAtLeast(0.9f)
        Color.HSVToColor(hsv)
    } catch (e: Exception) {
        fallback
    }
}

/** Cor de destaque do app para o brilho da notificação: 0 = padrão do app (sem brilho); senão clareia para aparecer no fundo preto. */
fun vividAccent(color: Int): Int {
    if (color == 0 || Color.alpha(color) == 0) return 0
    val hsv = FloatArray(3)
    Color.colorToHSV(color, hsv)
    if (hsv[1] < 0.15f) return 0   // branco/cinza: sem cor para destacar
    hsv[1] = hsv[1].coerceAtLeast(0.55f)
    hsv[2] = hsv[2].coerceAtLeast(0.9f)
    return Color.HSVToColor(hsv)
}
