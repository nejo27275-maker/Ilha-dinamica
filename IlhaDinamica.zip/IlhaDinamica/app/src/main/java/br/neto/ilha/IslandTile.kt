package br.neto.ilha

import android.content.Intent
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Botão nas Configurações rápidas para ligar/desligar a ilha. */
class IslandTile : TileService() {

    override fun onStartListening() {
        paint(IslandService.running)
    }

    override fun onClick() {
        val svc = Intent(this, IslandService::class.java)
        if (IslandService.running) {
            Watchdog.setWant(this, false); stopService(svc); paint(false)
        } else if (Settings.canDrawOverlays(this)) {
            Watchdog.setWant(this, true); startForegroundService(svc); paint(true)
        }
    }

    private fun paint(on: Boolean) {
        qsTile?.apply {
            state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }
}
