package br.neto.ilha

import android.content.Context

object Metrics {
    private fun today(): String =
        java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    /** Ciclos de foco concluídos hoje (zera sozinho na virada do dia). */
    fun focusToday(c: Context): Int {
        val p = c.getSharedPreferences("ilha", Context.MODE_PRIVATE)
        return if (p.getString("timerFocoDia", "") == today()) p.getInt("timerFocoN", 0) else 0
    }

    /** Data (yyyyMMdd) de [back] dias atrás; 0 = hoje. */
    private fun dayKey(back: Int): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -back)
        return java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(cal.time)
    }

    /** Histórico guardado como "20261002=3;20261001=2". */
    private fun history(c: Context): MutableMap<String, Int> {
        val raw = c.getSharedPreferences("ilha", Context.MODE_PRIVATE).getString("timerFocoHist", "") ?: ""
        val m = HashMap<String, Int>()
        for (part in raw.split(';')) {
            val kv = part.split('=')
            if (kv.size == 2) kv[1].toIntOrNull()?.let { m[kv[0]] = it }
        }
        return m
    }

    /** Conta mais um foco concluído hoje e devolve o total do dia (também alimenta o histórico de 7 dias). */
    fun addFocus(c: Context): Int {
        val n = focusToday(c) + 1
        val h = history(c)
        h[today()] = n
        val oldest = dayKey(13)   // guarda só as últimas 2 semanas
        val keep = h.filterKeys { it >= oldest }
        c.getSharedPreferences("ilha", Context.MODE_PRIVATE).edit()
            .putString("timerFocoDia", today()).putInt("timerFocoN", n)
            .putString("timerFocoHist", keep.entries.joinToString(";") { "${it.key}=${it.value}" })
            .apply()
        return n
    }

    /** Texto do painel: focos de hoje, sequência de dias e os últimos 7 dias. */
    fun focusSummary(c: Context): String {
        val h = history(c)
        val sdf = java.text.SimpleDateFormat("EEE", java.util.Locale("pt", "BR"))
        val days = StringBuilder()
        var total = 0
        for (back in 6 downTo 0) {
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.DAY_OF_YEAR, -back)
            val n = h[dayKey(back)] ?: 0
            total += n
            if (days.isNotEmpty()) days.append("  ")
            days.append(sdf.format(cal.time).trim('.')).append(' ').append(n)
        }
        // sequência: dias seguidos com pelo menos 1 foco (se hoje ainda está zerado, conta a partir de ontem)
        var streak = 0
        var back = if ((h[dayKey(0)] ?: 0) > 0) 0 else 1
        while (back < 14 && (h[dayKey(back)] ?: 0) > 0) { streak++; back++ }
        val seq = if (streak > 0) "\nSequência: $streak ${if (streak == 1) "dia" else "dias"}" else ""
        val meta = c.getSharedPreferences("ilha", Context.MODE_PRIVATE).getInt("focoMeta", 4)
        val hoje = focusToday(c).toString() + (if (meta > 0) " de $meta" else "")
        return "Focos concluídos hoje: $hoje$seq\nÚltimos 7 dias ($total): $days"
    }

    /** Apaga o contador do dia e o histórico de focos. */
    fun clearFocus(c: Context) {
        c.getSharedPreferences("ilha", Context.MODE_PRIVATE).edit()
            .remove("timerFocoDia").remove("timerFocoN").remove("timerFocoHist").apply()
    }

    /** m:ss; a partir de 1 hora, h:mm:ss. */
    fun clock(ms: Long): String {
        val secs = ((ms + 999) / 1000).toInt()
        val s = (secs % 60).toString().padStart(2, '0')
        return if (secs >= 3600) "${secs / 3600}:${((secs % 3600) / 60).toString().padStart(2, '0')}:$s" else "${secs / 60}:$s"
    }

    /**
     * "Descer ao expandir" padrão: altura real da barra de status deste aparelho, para o cartão
     * começar logo abaixo dela (usado enquanto você não mexer no controle).
     */
    fun autoDrop(c: Context): Int {
        val r = c.resources
        val d = r.displayMetrics.density
        val id = r.getIdentifier("status_bar_height", "dimen", "android")
        val px = if (id > 0) r.getDimensionPixelSize(id) else (24 * d).toInt()
        val top = c.getSharedPreferences("ilha", Context.MODE_PRIVATE).getInt("top", 4)
        return (px / d + 2f - top).toInt().coerceIn(0, 60)
    }
}
