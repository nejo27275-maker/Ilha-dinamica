package br.neto.ilha

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if ((i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) &&
            c.getSharedPreferences("ilha", Context.MODE_PRIVATE).getBoolean("boot", true) &&
            !Watchdog.userOff(c) &&   // se você apertou Desligar, continua desligada depois de reiniciar/atualizar
            Settings.canDrawOverlays(c)
        ) {
            Watchdog.setWant(c, true)
            Watchdog.schedule(c)
            c.startForegroundService(Intent(c, IslandService::class.java))
        }
    }
}
