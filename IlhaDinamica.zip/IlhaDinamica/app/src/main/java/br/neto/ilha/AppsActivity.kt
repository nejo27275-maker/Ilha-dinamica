package br.neto.ilha

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Lista de apps: os silenciados (NÃO aparecem na ilha) ou, com o extra "focus", os que furam o modo foco. */
class AppsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ilha", MODE_PRIVATE)
        val focus = intent.getBooleanExtra("focus", false)
        val key = if (focus) "focoAllow" else "muted"
        val muted = (prefs.getStringSet(key, null) ?: emptySet()).toMutableSet()
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (16 * d).toInt()
            setPadding(p, p * 2, p, p)
        }
        col.addView(TextView(this).apply {
            text = if (focus) "Apps que furam o modo foco\nMarque os apps cujos avisos DEVEM aparecer na ilha mesmo durante o foco."
                else "Apps silenciados\nMarque os apps que NÃO devem aparecer na ilha."
            textSize = 16f
        })
        val search = EditText(this).apply {
            hint = "Buscar app…"
            setSingleLine()
        }
        col.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)

        val pm = packageManager
        val already = muted.toSet()
        // silenciados primeiro, depois ordem alfabética
        val launcher = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
        // apps silenciados pelo botão da ilha que não têm ícone de lançador também aparecem (senão não dava para desfazer)
        val hidden = already.filter { p -> launcher.none { it.first == p } }.map { p ->
            p to (try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p })
        }
        val apps = (launcher + hidden)
            .sortedWith(compareByDescending<Pair<String, String>> { it.first in already }
                .thenBy { it.second.lowercase() })

        fun render(q: String) {
            list.removeAllViews()
            for ((pkg, name) in apps) {
                if (q.isNotEmpty() && !name.lowercase().contains(q)) continue
                list.addView(CheckBox(this).apply {
                    text = name
                    isChecked = pkg in muted
                    setOnCheckedChangeListener { _, on ->
                        if (on) muted.add(pkg) else muted.remove(pkg)
                        prefs.edit().putStringSet(key, HashSet(muted)).apply()
                    }
                })
            }
        }
        render("")
        // desfaz todos os silenciamentos de uma vez
        col.addView(Button(this).apply {
            text = "Desmarcar todos"; isAllCaps = false
            setOnClickListener {
                muted.clear()
                prefs.edit().putStringSet(key, HashSet()).apply()
                render(search.text.toString().trim().lowercase())
            }
        }, 1)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = render(s.toString().trim().lowercase())
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
