package br.neto.ilha

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.text.InputType
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("ilha", MODE_PRIVATE) }
    private var status: TextView? = null
    private var focusInfo: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ErrorLog.install(this)
        if (IslandService.running && !Watchdog.userOff(this)) Watchdog.setWant(this, true)
        Watchdog.schedule(this)
        if (Watchdog.want(this)) { KeepAlive.arm(this); Watchdog.revive(this) }
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (20 * d).toInt()
            setPadding(p, p * 2, p, p)
        }
        var target: LinearLayout = col   // onde os próximos itens entram (muda dentro de uma seção recolhível)
        fun add(v: View) = target.addView(v)
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setPadding(0, (14 * d).toInt(), 0, 0)
        }.also { add(it) }
        fun header(t: String) = TextView(this).apply {
            text = t; textSize = 17f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(90, 200, 250))
            setPadding(0, (24 * d).toInt(), 0, (2 * d).toInt())
        }.also { add(it) }
        fun button(t: String, f: () -> Unit) = add(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
        })
        fun slider(name: String, key: String, min: Int, max: Int, def: Int, unit: String = "dp") {
            val tv = label("")
            val sb = SeekBar(this)
            sb.max = max - min
            sb.progress = prefs.getInt(key, def) - min
            tv.text = "$name: ${prefs.getInt(key, def)} $unit"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    tv.text = "$name: ${p + min} $unit"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    prefs.edit().putInt(key, (s?.progress ?: 0) + min).apply()
                    if (IslandService.running) send(IslandService.ACT_RELOAD)
                }
            })
            add(sb)
        }

        fun check(t: String, key: String, def: Boolean) = add(CheckBox(this).apply {
            text = t
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, v ->
                prefs.edit().putBoolean(key, v).apply()
                if (IslandService.running) send(IslandService.ACT_RELOAD)
            }
        })

        /** Seção que abre/fecha ao tocar no título (a lista de testes é grande e ficava no caminho). */
        fun group(title: String, startOpen: Boolean, content: () -> Unit) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (startOpen) View.VISIBLE else View.GONE
            }
            val head = Button(this)
            head.isAllCaps = false
            fun paint() { head.text = (if (box.visibility == View.VISIBLE) "▾ " else "▸ ") + title }
            head.setOnClickListener {
                box.visibility = if (box.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                paint()
            }
            paint()
            add(head)
            val prev = target
            target = box
            content()
            target = prev
            add(box)
        }

        label("Ilha Dinâmica para Android\nvisual inspirado no iOS 27").textSize = 20f
        status = label("")
        header("Passo a passo")
        button("1 · Permitir sobreposição") {
            if (!Settings.canDrawOverlays(this))
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else toast("Já permitido")
        }
        button("2 · Permitir acesso às notificações") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3 · Ligar a ilha") {
            if (!Settings.canDrawOverlays(this)) toast("Faça o passo 1 primeiro")
            else { Watchdog.setWant(this, true); Watchdog.schedule(this); startForegroundService(Intent(this, IslandService::class.java)) }
        }
        button("Desligar a ilha") { Watchdog.setWant(this, false); stopService(Intent(this, IslandService::class.java)) }
        button("4 · Não deixar o sistema matar a ilha (bateria)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }

        group("Testar (ver o visual de cada recurso)", false) {
            button("Siri (pesquisar ou perguntar)") { send(IslandService.ACT_SIRI) }
            button("Notificação") { send(IslandService.ACT_NOTIF) }
            button("Código de verificação (teste)") { send(IslandService.ACT_CODE) }
            button("Música") { send(IslandService.ACT_MEDIA) }
            button("Carregando") { send(IslandService.ACT_CHARGE) }
            button("Bateria fraca") { send(IslandService.ACT_LOW) }
            button("Chamada") { send(IslandService.ACT_CALL) }
            button("Em chamada (teste)") { send(IslandService.ACT_INCALL) }
            button("Bluetooth (teste)") { send(IslandService.ACT_BT) }
            button("Silencioso (teste)") { send(IslandService.ACT_RING) }
            button("Não perturbe (teste)") { send(IslandService.ACT_DND) }
            button("Modo avião (teste)") { send(IslandService.ACT_SYS) }
            button("Atividade ao vivo (teste)") { send(IslandService.ACT_LIVE) }
            button("Tempo da cidade (teste)") { send(IslandService.ACT_WEATHER) }
        }

        header("Timer")
        button("Timer de 1 minuto") { send(IslandService.ACT_TIMER, 60) }
        button("Timer de 5 minutos") { send(IslandService.ACT_TIMER, 300) }
        button("Iniciar foco (duração ajustável abaixo)") { send(IslandService.ACT_TIMER, prefs.getInt("focoMin", 25).coerceIn(5, 90) * 60, "Foco") }
        button("Timer de 10 segundos (testar o aviso final)") { send(IslandService.ACT_TIMER, 10, "Teste") }
        button("Timer personalizado…") {
            val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "minutos" }
            AlertDialog.Builder(this)
                .setTitle("Timer (minutos)")
                .setView(et)
                .setPositiveButton("Iniciar") { _, _ ->
                    val m = et.text.toString().toIntOrNull() ?: 0
                    if (m in 1..600) send(IslandService.ACT_TIMER, m * 60) else toast("Use de 1 a 600")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        button("Cancelar timer") { send(IslandService.ACT_TIMER_STOP) }
        slider("Duração do foco", "focoMin", 5, 90, 25, "min")
        slider("Duração da pausa", "pausaMin", 1, 30, 5, "min")
        slider("Pausa longa a cada 4 focos (0 = sem pausa longa)", "pausaLongMin", 0, 45, 15, "min")
        slider("Meta diária de focos (0 = sem meta)", "focoMeta", 0, 12, 4, "focos")
        check("Tocar um som curto quando o timer acabar (respeita silencioso e Não perturbe)", "somTimer", true)
        focusInfo = label("")

        button("Zerar histórico de focos") {
            AlertDialog.Builder(this)
                .setTitle("Zerar histórico de focos?")
                .setMessage("Apaga os focos de hoje, a sequência e os últimos 7 dias.")
                .setPositiveButton("Zerar") { _, _ ->
                    Metrics.clearFocus(this)
                    focusInfo?.text = Metrics.focusSummary(this)
                    toast("Histórico zerado")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        header("Tempo")
        val weatherInfo = label("")
        fun paintWeather() {
            weatherInfo.text = if (Weather.configured(this)) "Cidade: ${Weather.city(this)}"
            else "Nenhuma cidade escolhida. Toque em \"Cidade do tempo…\"."
        }
        paintWeather()
        button("Cidade do tempo…") {
            val atual = Weather.city(this).substringBefore(',')
            val et = EditText(this).apply { hint = "ex.: Itu"; setSingleLine(); setText(atual) }
            AlertDialog.Builder(this)
                .setTitle("Cidade do tempo")
                .setMessage("Digite o nome da sua cidade (precisa de internet nessa hora).")
                .setView(et)
                .setPositiveButton("Salvar") { _, _ ->
                    val q = et.text.toString().substringBefore(',').trim()
                    if (q.length < 2) toast("Digite o nome da cidade")
                    else {
                        toast("Procurando…")
                        Thread {
                            val pl = try { Weather.geocode(q) } catch (e: Exception) { null }
                            runOnUiThread {
                                if (pl == null) toast("Não achei essa cidade (ou está sem internet)")
                                else {
                                    Weather.save(this, pl); paintWeather(); toast("Cidade: ${pl.label}")
                                    if (IslandService.running) send(IslandService.ACT_WEATHER)
                                }
                            }
                        }.start()
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        check("Mostrar o tempo ao desbloquear (no máximo a cada 2 h)", "weatherGlance", true)
        button("Ver o tempo agora") { send(IslandService.ACT_WEATHER) }

        header("Recursos")
        group("Notificações", true) {
            check("Mostrar notificações", "notif", true)
            check("Só notificações importantes (ignora as silenciosas)", "imp", true)
            check("Brilho colorido (notificações, carregador, timer, chamada)", "ntint", true)
            check("Vibração leve ao notificar", "vib", true)
            check("Ocultar o texto das mensagens (mostra só o remetente)", "hide", false)
            check("Esconder o texto com o celular bloqueado (mostra só o remetente)", "hideLocked", true)
        }
        group("Música", false) {
            check("Mostrar música (player na ilha)", "media", true)
            check("Mostrar a música ao trocar de faixa", "pop", true)
            check("Esconder música/vídeo pausado quando eu tocar fora da ilha", "hidePaused", true)
        }
        group("Avisos do sistema", false) {
            check("Aviso ao ligar o carregador e ao chegar a 100%", "charge", true)
            check("Aviso de bateria fraca", "low", true)
            check("Atividade ao vivo (progresso de downloads etc. na ilha)", "live", true)
            check("Aviso ao conectar Bluetooth (fone, caixa…)", "bt", true)
            check("Aviso ao mudar silencioso/vibrar e Não perturbe", "ring", true)
            check("Aviso de modo avião e fone com fio", "sys", true)
        }
        group("Foco e timer", false) {
            check("Silenciar os avisos comuns da ilha durante o foco", "focoQuiet", true)
            check("Começar a pausa sozinho ao fim do foco", "focoAuto", false)
        }
        group("Geral", false) {
            check("Permitir avisos de fora (Termux/Tasker)", "api", true)
            check("Siri (segurar a pílula)", "siri", true)
            check("Iniciar com o celular", "boot", true)
            check("Mostrar também na horizontal (celular deitado)", "land", true)
            check("Esconder em tela cheia (experimental)", "fs", false)
        }

        button("Senha da API de fora (opcional)…") {
            val et = EditText(this).apply {
                hint = "vazio = sem senha"; setSingleLine()
                setText(prefs.getString("apiKey", ""))
            }
            AlertDialog.Builder(this)
                .setTitle("Senha da API")
                .setMessage("Com senha, scripts precisam mandar  --es key SENHA  junto com o comando. Sem isso, qualquer app do celular consegue mandar avisos para a ilha.")
                .setView(et)
                .setPositiveButton("Salvar") { _, _ ->
                    val k = et.text.toString().trim()
                    prefs.edit().putString("apiKey", k).apply()
                    toast(if (k.isEmpty()) "API sem senha" else "Senha salva")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        button("Copiar comando de exemplo (Termux)") {
            val k = prefs.getString("apiKey", "") ?: ""
            val extra = if (k.isNotEmpty()) " --es key \"$k\"" else ""
            val cmd = "am broadcast -a br.neto.ilha.SHOW -n br.neto.ilha/.ExternalReceiver --es title \"Build\" --es text \"Pronto\" --ei sec 6$extra"
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("comando", cmd))
            toast("Comando copiado")
        }
        button("Apps silenciados…") { startActivity(Intent(this, AppsActivity::class.java)) }
        button("Apps que furam o modo foco…") { startActivity(Intent(this, AppsActivity::class.java).putExtra("focus", true)) }
        button("Ver registro de erros") {
            val log = ErrorLog.read(this).ifBlank { "Nenhum erro registrado." }
            AlertDialog.Builder(this)
                .setTitle("Registro de erros")
                .setMessage(log)
                .setPositiveButton("Copiar") { _, _ ->
                    getSystemService(ClipboardManager::class.java)
                        .setPrimaryClip(ClipData.newPlainText("erros", log))
                    toast("Copiado")
                }
                .setNeutralButton("Limpar") { _, _ -> ErrorLog.clear(this) }
                .setNegativeButton("Fechar", null)
                .show()
        }

        header("Ajuste ao seu aparelho (furo da câmera)")
        slider("Distância do topo", "top", 0, 40, 4)
        slider("Largura da pílula parada", "w", 50, 180, 96)
        slider("Descer ao expandir (player, avisos, chamada)", "drop", 0, 60, Metrics.autoDrop(this))
        slider("Largura dos cartões (player, avisos, chamada)", "cardw", 280, 380, 350)
        slider("Posição horizontal (câmera fora do centro)", "x", -60, 60, 0)
        slider("Tempo de cada notificação", "dur", 2, 10, 5, "s")
        slider("Intensidade do brilho colorido", "tintInt", 0, 200, 100, "%")
        slider("Duração do botão \"Pausar avisos\"", "pauseMin", 15, 240, 60, "min")
        button("Restaurar posição e tamanhos (padrão)") {
            prefs.edit().remove("top").remove("w").remove("x").remove("drop").remove("cardw").remove("dur").apply()
            if (IslandService.running) send(IslandService.ACT_RELOAD)
            toast("Ajustes restaurados")
            recreate()
        }
        button("Copiar minhas configurações (backup)") {
            val o = JSONObject()
            for ((k, v) in prefs.all) {
                if (k.startsWith("timer") || k == "pauseUntil" || k == "wCache") continue   // estado temporário, não é configuração
                when (v) {
                    is Boolean -> o.put(k, v)
                    is Int -> o.put(k, v)
                    is String -> o.put(k, v)
                    is Set<*> -> o.put(k, JSONArray(v.map { it.toString() }))
                    else -> {}
                }
            }
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ilha", o.toString()))
            toast("Configurações copiadas")
        }
        button("Colar configurações (restaurar backup)") {
            val txt = getSystemService(ClipboardManager::class.java).primaryClip
                ?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
            try {
                val o = JSONObject(txt ?: "")
                val e = prefs.edit()
                for (k in o.keys()) {
                    if (k.startsWith("timer") || k == "pauseUntil" || k == "wCache") continue
                    when (val v = o.get(k)) {
                        is Boolean -> e.putBoolean(k, v)
                        is Int -> e.putInt(k, v)
                        is String -> e.putString(k, v)
                        is JSONArray -> e.putStringSet(k, (0 until v.length()).map { v.getString(it) }.toSet())
                        else -> {}
                    }
                }
                e.apply()
                if (IslandService.running) send(IslandService.ACT_RELOAD)
                toast("Configurações restauradas")
                recreate()
            } catch (ex: Exception) { toast("Copie primeiro o backup (texto) e tente de novo") }
        }
        label("Silêncio por horário: nesse período as notificações não aparecem na ilha (chamadas e timer continuam). Início e fim iguais = desligado.")
        slider("Silêncio: começa às", "qs", 0, 23, 0, "h")
        slider("Silêncio: termina às", "qe", 0, 23, 0, "h")
        label("Dica: segure a pílula para chamar a Siri. Música: toque ou deslize para baixo para expandir, para os lados troca de faixa, arraste a barra para pular. Deslize para cima para fechar. Toque no timer para pausar/retomar; toque na capa para abrir o player. Quando o timer acabar, deslize para baixo no aviso para +1 ou +5 min.")
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        label("Versão $ver").textSize = 12f

        setContentView(ScrollView(this).apply { addView(col) })

        val need = mutableListOf<String>()
        fun missing(p: String) = checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT >= 33 && missing(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31 && missing(Manifest.permission.BLUETOOTH_CONNECT)) need.add(Manifest.permission.BLUETOOTH_CONNECT)   // nome do aparelho Bluetooth
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val bat = getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(packageName) == true
        fun ok(b: Boolean) = if (b) "✓" else "✗"
        status?.text = "Sobreposição ${ok(ov)}   Notificações ${ok(nl)}   Bateria ${ok(bat)}   Ilha ${if (IslandService.running) "ligada" else "desligada"}"
        focusInfo?.text = Metrics.focusSummary(this)
        status?.setTextColor(if (ov && nl && IslandService.running) Color.rgb(48, 209, 88) else Color.rgb(255, 159, 10))
    }

    private fun send(action: String, sec: Int = 0, label: String = "") {
        if (!Settings.canDrawOverlays(this)) { toast("Faça o passo 1 primeiro"); return }
        startForegroundService(
            Intent(this, IslandService::class.java).setAction(action).putExtra("sec", sec).putExtra("label", label)
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
