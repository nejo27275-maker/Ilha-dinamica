package br.neto.ilha

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registro simples de erros em arquivo, para você poder ver/copiar o que deu errado dentro do app. */
object ErrorLog {
    private const val FILE = "erros.txt"
    private var last = 0L
    private var installed = false

    fun add(ctx: Context, where: String, t: Throwable) {
        try {
            val now = System.currentTimeMillis()
            if (now - last < 3000) return   // evita encher o arquivo se o erro se repetir a cada quadro
            last = now
            val f = File(ctx.applicationContext.filesDir, FILE)
            if (f.length() > 20_000) f.writeText("")
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            val stamp = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date())
            f.appendText("[$stamp] $where\n${sw.toString().take(1500)}\n\n")
        } catch (e: Exception) {
        }
    }

    /** Cabeçalho com versão do app, do Android e modelo: facilita achar o erro quando o log é colado. */
    private fun header(ctx: Context): String {
        val v = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" }
        return "Ilha Dinâmica $v • Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) • ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n\n"
    }

    fun read(ctx: Context): String = try {
        val f = File(ctx.applicationContext.filesDir, FILE)
        if (f.exists() && f.length() > 0L) header(ctx) + f.readText() else ""
    } catch (e: Exception) {
        ""
    }

    fun clear(ctx: Context) {
        try { File(ctx.applicationContext.filesDir, FILE).delete() } catch (e: Exception) {}
    }

    /** Anota travamentos (crash) antes de o Android encerrar o app. */
    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            last = 0L
            add(app, "TRAVAMENTO em ${th.name}", e)
            if (Watchdog.want(app)) KeepAlive.arm(app, 2000L)   // travou: o guarda-costas religa a ilha em 2 s
            prev?.uncaughtException(th, e)
        }
    }
}
