package br.neto.ilha

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/**
 * Tempo da cidade (Open-Meteo: grátis, sem chave, sem conta). Só usa a internet para isto:
 * 1 consulta quando você escolhe a cidade e 1 a cada vez que o tempo aparece (no máximo a cada 30 min).
 */
object Weather {
    class Now(
        val city: String, val temp: Int, val code: Int, val day: Boolean,
        val max: Int, val min: Int, val rain: Int, val at: Long
    )

    class Place(val label: String, val lat: Double, val lon: Double)

    private const val FRESH = 30 * 60_000L

    private fun p(c: Context) = c.getSharedPreferences("ilha", Context.MODE_PRIVATE)

    fun configured(c: Context): Boolean =
        !p(c).getString("wLat", "").isNullOrEmpty() && !p(c).getString("wLon", "").isNullOrEmpty()

    fun city(c: Context): String = p(c).getString("wLabel", "") ?: ""

    fun save(c: Context, pl: Place) {
        p(c).edit()
            .putString("wLabel", pl.label)
            .putString("wLat", pl.lat.toString())
            .putString("wLon", pl.lon.toString())
            .remove("wCache")
            .apply()
    }

    fun fresh(n: Now): Boolean = System.currentTimeMillis() - n.at < FRESH

    fun cached(c: Context): Now? {
        val raw = p(c).getString("wCache", null) ?: return null
        return try {
            val o = JSONObject(raw)
            Now(
                o.getString("city"), o.getInt("t"), o.getInt("c"), o.getBoolean("d"),
                o.getInt("x"), o.getInt("n"), o.getInt("r"), o.getLong("at")
            )
        } catch (e: Exception) { null }
    }

    private fun get(url: String): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 8000
        try {
            if (con.responseCode != 200) throw java.io.IOException("HTTP ${con.responseCode}")
            return con.inputStream.bufferedReader().use { it.readText() }
        } finally {
            con.disconnect()
        }
    }

    /** Procura a cidade pelo nome (prefere o Brasil se houver). Bloqueia: chame fora da tela principal. */
    fun geocode(q: String): Place? {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(q, "UTF-8") + "&count=8&language=pt&format=json"
        val arr = JSONObject(get(url)).optJSONArray("results") ?: return null
        if (arr.length() == 0) return null
        var pick = arr.getJSONObject(0)
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (r.optString("country_code") == "BR") { pick = r; break }
        }
        val name = pick.getString("name")
        val st = pick.optString("admin1", "")
        val label = if (st.isNotEmpty() && st != name) "$name, $st" else name
        return Place(label, pick.getDouble("latitude"), pick.getDouble("longitude"))
    }

    /** Busca o tempo agora e guarda em cache. Bloqueia: chame em outra thread. Devolve null se falhar. */
    fun fetch(c: Context): Now? {
        if (!configured(c)) return null
        return try {
            val lat = p(c).getString("wLat", "") ?: ""
            val lon = p(c).getString("wLon", "") ?: ""
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,is_day" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=1"
            val o = JSONObject(get(url))
            val cur = o.getJSONObject("current")
            val d = o.getJSONObject("daily")
            val n = Now(
                city(c),
                cur.getDouble("temperature_2m").roundToInt(),
                cur.getInt("weather_code"),
                cur.optInt("is_day", 1) == 1,
                d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                d.getJSONArray("precipitation_probability_max").optInt(0),
                System.currentTimeMillis()
            )
            val j = JSONObject()
                .put("city", n.city).put("t", n.temp).put("c", n.code).put("d", n.day)
                .put("x", n.max).put("n", n.min).put("r", n.rain).put("at", n.at)
            p(c).edit().putString("wCache", j.toString()).apply()
            n
        } catch (e: java.io.IOException) {
            null   // sem internet: sem alarde
        } catch (e: Exception) {
            ErrorLog.add(c, "tempo", e); null
        }
    }

    /** Códigos WMO do Open-Meteo em português. */
    fun describe(code: Int): String = when (code) {
        0 -> "Céu limpo"
        1 -> "Quase limpo"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Neblina"
        51, 53, 55 -> "Garoa"
        56, 57 -> "Garoa congelante"
        61 -> "Chuva fraca"
        63 -> "Chuva"
        65 -> "Chuva forte"
        66, 67 -> "Chuva congelante"
        71, 73, 75, 77 -> "Neve"
        80, 81 -> "Pancadas de chuva"
        82 -> "Chuva muito forte"
        85, 86 -> "Pancadas de neve"
        95 -> "Trovoada"
        96, 99 -> "Trovoada com granizo"
        else -> "Tempo variável"
    }

    fun emoji(code: Int, day: Boolean): String = when (code) {
        0 -> if (day) "☀️" else "🌙"
        1 -> if (day) "🌤️" else "🌙"
        2 -> if (day) "⛅" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }

    /** Ícone do cartão: o emoji do tempo desenhado num quadrado escuro. */
    fun icon(c: Context, emoji: String): Drawable {
        val s = 96
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        cv.drawColor(Color.rgb(44, 44, 46))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = s * 0.62f
        paint.textAlign = Paint.Align.CENTER
        val fm = paint.fontMetrics
        cv.drawText(emoji, s / 2f, s / 2f - (fm.ascent + fm.descent) / 2f, paint)
        return BitmapDrawable(c.resources, b)
    }
}
