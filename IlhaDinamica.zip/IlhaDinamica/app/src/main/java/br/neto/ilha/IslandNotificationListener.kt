package br.neto.ilha

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar

class IslandNotificationListener : NotificationListenerService() {

    private val ui = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var current: MediaController? = null
    /** Todas as sessões de mídia ativas (para trocar de player quando outro começa a tocar). */
    private var all: List<MediaController> = emptyList()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = repick()
        override fun onSessionDestroyed() = repick()
    }

    override fun onListenerConnected() {
        Watchdog.revive(this)
        Watchdog.schedule(this)
        IslandBus.cancel = { k -> try { cancelNotification(k) } catch (e: Exception) {} }
        val mgr = getSystemService(MediaSessionManager::class.java)
        msm = mgr
        val cn = ComponentName(this, IslandNotificationListener::class.java)
        try {
            mgr.addOnActiveSessionsChangedListener(sessionsListener, cn, ui)
            pick(mgr.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // sem acesso às notificações ainda
        }
    }

    override fun onListenerDisconnected() {
        IslandBus.cancel = null
        msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        all.forEach { try { it.unregisterCallback(callback) } catch (e: Exception) {} }
        all = emptyList()
        current = null
        // alguns aparelhos (Samsung) derrubam o listener: pede para reconectar sozinho
        try {
            requestRebind(ComponentName(this, IslandNotificationListener::class.java))
        } catch (e: Exception) {}
    }

    private fun pick(list: List<MediaController>?) {
        all.forEach { try { it.unregisterCallback(callback) } catch (e: Exception) {} }
        all = list ?: emptyList()
        all.forEach { it.registerCallback(callback, ui) }
        repick()
    }

    private fun isPlaying(c: MediaController?) = c?.playbackState?.state == PlaybackState.STATE_PLAYING

    /** Fica no player atual enquanto ele toca; se parar e outro estiver tocando, troca para ele. */
    private fun repick() {
        val cur = current
        val stillThere = cur != null && all.any { it.sessionToken == cur.sessionToken }
        current = when {
            stillThere && isPlaying(cur) -> cur
            all.any { isPlaying(it) } -> all.first { isPlaying(it) }
            stillThere -> cur
            else -> all.firstOrNull()
        }
        publish()
    }

    private fun publish() {
        val c = current
        val md = c?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val st = c?.playbackState
        val m = if (c == null || md == null || title == null) null else IslandBus.Media(
            title = title,
            artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: "",
            art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON),
            playing = st?.state == PlaybackState.STATE_PLAYING,
            durationMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
            positionMs = st?.position ?: 0L,
            updatedAt = st?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
            speed = st?.playbackSpeed ?: 1f,
            controller = c,
            open = try { c.sessionActivity } catch (e: Exception) { null }
        )
        IslandBus.media = m
        IslandBus.onMedia?.invoke(m)
    }

    private var callKey: String? = null
    /** Última assinatura (título+texto) por notificação, para não repetir a mesma. */
    private val seen = HashMap<String, Int>()
    private var activeKey: String? = null
    private var activeStart = 0L

    private fun muted(): Set<String> =
        getSharedPreferences("ilha", MODE_PRIVATE).getStringSet("muted", null) ?: emptySet()

    /** Silêncio por horário: início e fim iguais = desligado; atravessa a meia-noite (ex.: 23h–7h). */
    private fun quiet(): Boolean {
        val p = getSharedPreferences("ilha", MODE_PRIVATE)
        val s = p.getInt("qs", 0)
        val e = p.getInt("qe", 0)
        if (s == e) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (s < e) h in s until e else h >= s || h < e
    }

    private val codeRe = Regex("(?<![\\d.,])\\d{4,8}(?![\\d.,])")
    private val codeWords = arrayOf("código", "codigo", "code", "token", "verifica", "senha", "otp")

    /** Código de verificação (SMS/app): só se o texto fala de código e é curto, para não pegar valores/telefones. */
    private fun findCode(t: String): String? {
        if (t.length > 300 || !has(t, *codeWords)) return null
        return codeRe.find(t)?.value
    }

    /** Anti-flood: um app que posta mais de 6 avisos diferentes em 5 s é ignorado até a janela passar. */
    private val burst = HashMap<String, LongArray>()
    private fun flood(pkg: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (burst.size > 60) burst.clear()
        val b = burst.getOrPut(pkg) { longArrayOf(now, 0L) }
        if (now - b[0] > 5000L) { b[0] = now; b[1] = 0L }
        b[1]++
        return b[1] > 6
    }

    private fun has(t: CharSequence?, vararg words: String): Boolean {
        val s = t?.toString()?.lowercase() ?: return false
        return words.any { s.contains(it) }
    }

    /** Chamada recebida = notificação CATEGORY_CALL com ação de atender (sem permissão extra). */
    private fun handleCall(sbn: StatusBarNotification, n: Notification) {
        val acts = n.actions
        val ans = acts?.firstOrNull { has(it.title, "atend", "answer", "accept", "aceit") }
        if (acts == null || ans == null) {
            if (sbn.key == callKey) { callKey = null; ui.post { IslandBus.onCall?.invoke(null) } }
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) {
                // chamada em andamento: mostra duração na ilha
                val chrono = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER) && n.`when` > 0
                val start = when {
                    chrono -> SystemClock.elapsedRealtime() - (System.currentTimeMillis() - n.`when`)
                    sbn.key == activeKey && activeStart > 0 -> activeStart
                    else -> SystemClock.elapsedRealtime()
                }
                activeKey = sbn.key
                activeStart = start
                val act = IslandBus.Active(start, n.contentIntent)
                ui.post { IslandBus.onActive?.invoke(act) }
            }
            return
        }
        val dec = acts.firstOrNull {
            it !== ans && has(it.title, "recus", "decline", "reject", "rejeit", "ignor", "dismiss")
        } ?: acts.firstOrNull { it !== ans }
        val ex = n.extras
        val name = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Chamada"
        val sub = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "Chamada recebida"
        val large = try { n.getLargeIcon()?.loadDrawable(this) } catch (e: Exception) { null }
        callKey = sbn.key
        val call = IslandBus.Call(name, sub, large, ans.actionIntent, dec?.actionIntent)
        ui.post { IslandBus.onCall?.invoke(call) }
    }

    /** Várias atividades ao mesmo tempo (ex.: 2 downloads): a ilha mostra a que atualizou por último. */
    private val lives = LinkedHashMap<String, IslandBus.Live>()

    private fun endLive(key: String) {
        if (lives.remove(key) == null) return
        val next = lives.values.lastOrNull()   // se outra ainda roda, ela assume a pílula
        ui.post { IslandBus.onLive?.invoke(next) }
    }

    /** Progresso (download etc.) vira "atividade ao vivo" na ilha. Retorna true se tratou a notificação. */
    private fun handleLive(sbn: StatusBarNotification, n: Notification): Boolean {
        val p = getSharedPreferences("ilha", MODE_PRIVATE)
        if (!p.getBoolean("live", true)) return false
        val ex = n.extras
        val max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        if (max <= 0 || ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE)) return false
        if (n.category == Notification.CATEGORY_TRANSPORT) return false
        val frac = (ex.getInt(Notification.EXTRA_PROGRESS, 0).toFloat() / max).coerceIn(0f, 1f)
        if (frac >= 1f) {
            // só avisa "Concluído" se a atividade já estava rodando na ilha (não para progresso que nasce completo)
            val done = lives[sbn.key]
            endLive(sbn.key)
            if (done != null) {
                val msg = IslandBus.Notif(done.title, "Concluído", done.title, done.icon, done.intent, holdMs = 4000L)
                ui.post { IslandBus.onNotif?.invoke(msg) }
            }
            return true
        }
        val pm = packageManager
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.takeIf { it.isNotBlank() }
            ?: try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
        val icon = try { n.getLargeIcon()?.loadDrawable(this) } catch (e: Exception) { null }
            ?: try { pm.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        val live = IslandBus.Live(sbn.key, title, icon, frac, n.contentIntent)
        lives.remove(sbn.key)          // reinsere no fim = "mais recente"
        if (lives.size > 8) lives.remove(lives.keys.first())
        lives[sbn.key] = live
        ui.post { IslandBus.onLive?.invoke(live) }
        return true
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        endLive(sbn.key)
        seen.remove(sbn.key)
        ui.post { IslandBus.onNotifRemoved?.invoke(sbn.key) }
        if (sbn.key == activeKey) {
            activeKey = null; activeStart = 0L
            ui.post { IslandBus.onActive?.invoke(null) }
        }
        if (sbn.key == callKey) {
            callKey = null
            ui.post { IslandBus.onCall?.invoke(null) }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!IslandService.running) Watchdog.revive(this)   // chegou aviso e a ilha caiu: religa na hora
        try { handlePosted(sbn) } catch (e: Exception) { ErrorLog.add(this, "notificação ${sbn.packageName}", e) }
    }

    private fun handlePosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return
        if (n.category == Notification.CATEGORY_CALL) { handleCall(sbn, n); return }
        if (sbn.packageName in muted()) return
        if (handleLive(sbn, n)) return
        val urgent = n.category == Notification.CATEGORY_ALARM ||
            n.category == Notification.CATEGORY_REMINDER ||
            n.category == Notification.CATEGORY_EVENT ||
            n.category == "missed_call"   // chamada perdida (literal: a constante só existe em Androids novos)
        if ((quiet() || PauseTile.paused(this)) && !urgent) return
        // tela apagada: o aviso fica só na gaveta de notificações (a ilha nem está visível)
        // (os prioritários passam: ficam na fila e aparecem ao desbloquear)
        if (!urgent && getSystemService(PowerManager::class.java)?.isInteractive == false) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT ||
            n.category == Notification.CATEGORY_PROGRESS
        ) return

        // respeita "Não perturbe" e (opcional) ignora notificações silenciosas
        val rk = NotificationListenerService.Ranking()
        if (currentRanking.getRanking(sbn.key, rk)) {
            if (!rk.matchesInterruptionFilter()) return
            val onlyImportant = getSharedPreferences("ilha", MODE_PRIVATE).getBoolean("imp", true)
            if (onlyImportant && !urgent && rk.importance < NotificationManager.IMPORTANCE_DEFAULT) return
        }

        val ex = n.extras
        val titleRaw = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val pf = getSharedPreferences("ilha", MODE_PRIVATE)
        // privacidade: com o celular bloqueado (tela de bloqueio) mostra só o remetente, sem o texto
        val locked = getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true
        val hide = pf.getBoolean("hide", false) || (locked && pf.getBoolean("hideLocked", true))
        // texto curto ou, na falta, o texto longo (apps que só preenchem o "big text")
        val rawText = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        val text = if (hide) "" else rawText
        if (titleRaw.isNullOrBlank() && rawText.isBlank()) return

        // apps que repostam a mesma notificação (atualização de contador etc.) não reaparecem
        val sig = ((titleRaw ?: "") + "\u0000" + text).hashCode()
        if (seen[sbn.key] == sig) return
        // anti-flood ANTES de marcar como "visto": o aviso barrado pelo flood não fica perdido para sempre
        if (flood(sbn.packageName)) return
        if (seen.size > 120) seen.clear()
        seen[sbn.key] = sig

        val pm = packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val large = try { n.getLargeIcon()?.loadDrawable(this) } catch (e: Exception) { null }
        val title = titleRaw?.takeIf { it.isNotBlank() } ?: appName
        val icon = large ?: try {
            pm.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }
        val code = findCode((titleRaw ?: "") + " " + rawText)
        val real = n.actions
            ?.filter { a -> a.remoteInputs.isNullOrEmpty() && a.actionIntent != null && !a.title.isNullOrBlank() }
            ?.take(if (code != null) 1 else 2)
            ?.map { IslandBus.Act(it.title.toString(), it.actionIntent) }
            ?: emptyList()
        // código de verificação: botão "Copiar 123456" (com o texto oculto, não mostra o número)
        val copyAct = if (code != null)
            listOf(IslandBus.Act(if (hide) "Copiar código" else "Copiar $code", null, null, code))
        else emptyList()
        // último botão: silenciar o app direto da ilha (desfaz em "Apps silenciados")
        val acts = copyAct + real + IslandBus.Act("Silenciar app", null, sbn.packageName)
        val base = getSharedPreferences("ilha", MODE_PRIVATE).getInt("dur", 5) * 1000L
        val reading = (2500L + (title.length + text.length) * 55L).coerceAtMost(10_000L)
        val hold = if (urgent) 10_000L else if (reading > base) reading else 0L
        val notif = IslandBus.Notif(appName, title, text, icon, n.contentIntent, large != null, acts, key = sbn.key,
            holdMs = hold, autoCancel = n.flags and Notification.FLAG_AUTO_CANCEL != 0,
            sticky = urgent, accent = vividAccent(n.color))
        // modo foco: durante o timer "Foco" os avisos comuns ficam retidos (só contam; o total aparece no fim do foco)
        val pFoco = getSharedPreferences("ilha", MODE_PRIVATE)
        val furaFoco = sbn.packageName in (pFoco.getStringSet("focoAllow", null) ?: emptySet())
        if (!urgent && !furaFoco && IslandService.focusRunning && pFoco.getBoolean("focoQuiet", true)) {
            IslandService.focusMissed++
            return
        }
        ui.post { IslandBus.onNotif?.invoke(notif) }
    }
}
