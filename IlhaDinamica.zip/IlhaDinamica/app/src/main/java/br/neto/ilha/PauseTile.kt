package br.neto.ilha

import android.content.Context
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Botão nas Configurações rápidas: pausa os avisos comuns na ilha (60 min por padrão, ajustável no app); tocar de novo retoma. */
class PauseTile : TileService() {
    override fun onStartListening() = paint()

    override fun onClick() {
        val p = getSharedPreferences("ilha", MODE_PRIVATE)
        if (paused(this)) p.edit().remove("pauseUntil").apply()
        else p.edit().putLong("pauseUntil", System.currentTimeMillis() + p.getInt("pauseMin", 60) * 60_000L).apply()
        paint()
    }

    private fun paint() {
        qsTile?.apply {
            val on = paused(this@PauseTile)
            state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Pausar avisos"
            updateTile()
        }
    }

    companion object {
        /** Pausa ativa? Chamadas, timer, alarmes e lembretes continuam aparecendo. */
        fun paused(c: Context): Boolean =
            c.getSharedPreferences("ilha", Context.MODE_PRIVATE).getLong("pauseUntil", 0L) > System.currentTimeMillis()
    }
}
