package br.neto.ilha

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.provider.Settings
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.Choreographer
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * A ilha: pílula preta animada por FÍSICA DE MOLA (interrompível, mantém a velocidade),
 * desenhada em Canvas. O loop de quadros só roda quando há algo animando (poupa bateria).
 * Estilo iOS 27: borda "Liquid Glass" e Siri como orbe girando com brilho em volta.
 */
class IslandView(ctx: Context) : View(ctx) {

    enum class Mode { IDLE, COMPACT, EXPANDED, NOTIF, SIRI, CHARGE, TIMER, CALL, INCALL, PROGRESS }

    interface Host {
        fun onTap(mode: Mode)
        fun onLong(mode: Mode)
        fun onDismiss(mode: Mode)
        fun onAction(action: Int) // 0 anterior, 1 play/pause, 2 próxima, 10 recusar, 11 atender, 20 abrir o player
        fun onSeek(fraction: Float)
        fun onFrame(w: Int, h: Int)
        fun onExpandNotif()
        fun onNotifAction(index: Int)
        /** Tocou em qualquer lugar fora da ilha (a janela recebe o aviso, sem a posição). */
        fun onOutside()
    }

    var host: Host? = null
    var media: IslandBus.Media? = null
    var notif: IslandBus.Notif? = null
        set(v) {
            field = v
            // aviso novo no lugar do atual: se mudou entre 1 e 2 linhas, o cartão ajusta a altura
            if (mode == Mode.NOTIF && v != null && twoLines(v) != nTwo) setMode(mode, true)
        }
    /** O texto do aviso atual precisa de 2 linhas (o cartão fica 16 dp mais alto). */
    private var nTwo = false
    /** Brilho suave com a cor do app atrás da notificação (opção do app). */
    var tintNotif = true
    /** Intensidade do brilho colorido (1 = padrão, 0 = invisível, 2 = o dobro). */
    var tintK = 1f
    var battery = 0
    var batteryLow = false
    var queued = 0
    /** Aviso aberto mostrando os botões de ação (fica mais alto). */
    var actionsOpen = false
        set(v) { if (field != v) { field = v; setMode(mode, true) } }
    private val chip = RectF()
    var call: IslandBus.Call? = null
    var live: IslandBus.Live? = null
    var timerEnd = 0L
    var timerTotal = 1L
    var timerPaused = false
    var timerLeft = 0L
    var timerLabel = ""
    private fun timerLeftNow(): Long =
        if (timerPaused) timerLeft else (timerEnd - SystemClock.elapsedRealtime()).coerceAtLeast(0L)

    /** Relógio do timer: m:ss; a partir de 1 hora vira h:mm:ss (antes "90:00" / "600:00" ficava largo demais). */
    private fun clock(ms: Long): String {
        val secs = ((ms + 999) / 1000).toInt()
        val s = (secs % 60).toString().padStart(2, '0')
        return if (secs >= 3600) "${secs / 3600}:${((secs % 3600) / 60).toString().padStart(2, '0')}:$s" else "${secs / 60}:$s"
    }
    var activeStart = 0L
    var mode = Mode.IDLE
        private set

    private val d = resources.displayMetrics.density
    private var seeking = false   // arrastando a barra de progresso
    private var seekFrac = 0f
    private val padSmall = (4 * d).toInt()
    private val padBig = (18 * d).toInt()   // só a Siri precisa de espaço para o brilho
    var pad = padSmall
        private set
    /** Largura máxima da ilha: nunca passa da tela (telas estreitas / fonte grande). */
    // lado menor da tela: a mesma largura máxima em pé e deitado (a ilha agora também aparece na horizontal)
    private val maxPill = min(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels) - 16 * d
    private fun cw(dp: Float) = min(dp * d, maxPill)
    var idleW = 96 * d
        private set

    // mola: 0 = largura, 1 = altura, 2 = raio
    private val pos = FloatArray(3)
    private val vel = FloatArray(3)
    private val tgt = FloatArray(3)
    private var w = 0f
    private var h = 0f
    private var r = 0f
    private var rr = 0f
    private var content = 1f
    private var age = 1f
    private var phase = 0f
    private var last = 0L
    private var running = false
    private var lastW = 0
    private var lastH = 0
    private val STIFF = 380f
    private val DAMP = 25f

    private val TAU = (2 * Math.PI).toFloat()
    private val WHITE = Color.WHITE
    private val GRAY = Color.rgb(154, 154, 160)
    private val CYAN = Color.rgb(90, 200, 250)
    private val GREEN = Color.rgb(48, 209, 88)
    private val ORANGE = Color.rgb(255, 159, 10)
    private val RED = Color.rgb(255, 69, 58)
    private val arc = RectF()
    private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3 * d; strokeCap = Paint.Cap.ROUND
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.4f * d; strokeCap = Paint.Cap.ROUND; color = Color.WHITE
    }

    private val box = RectF()
    private val clip = Path()
    private val icon = Path()
    private val artRect = RectF()
    private val artPath = Path()
    private val mat = Matrix()

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG)
    // criados uma vez só (antes eram recriados a cada quadro)
    private val tfNormal: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val tfStrong: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val edgeShader = LinearGradient(
        0f, 0f, 0f, 1f,
        intArrayOf(0x66FFFFFF, 0x10FFFFFF, 0x30FFFFFF), floatArrayOf(0f, 0.5f, 1f),
        Shader.TileMode.CLAMP
    )
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.2f * d; shader = edgeShader
    }

    private val siriColors = intArrayOf(
        Color.rgb(90, 200, 250), Color.rgb(94, 92, 230), Color.rgb(191, 90, 242),
        Color.rgb(255, 55, 95), Color.rgb(255, 159, 10), Color.rgb(90, 200, 250)
    )
    private val sweepGlow = SweepGradient(0f, 0f, siriColors, null)
    private val sweepOrbA = SweepGradient(0f, 0f, siriColors, null)
    private val sweepOrbB = SweepGradient(0f, 0f, siriColors, null)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4 * d
        maskFilter = BlurMaskFilter(12 * d, BlurMaskFilter.Blur.NORMAL)
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.6f * d
    }
    // brilho ambiente com a cor da capa no player expandido (shader criado só quando a cor muda)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var tintColor = 0
    private var tintShader: RadialGradient? = null

    private val frame = Choreographer.FrameCallback { ts -> step(ts) }

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            if (mode == Mode.CALL) {
                val gx = box.right - 38 * d
                val rx = gx - 56 * d
                val cy = box.centerY()
                if (abs(e.x - gx) < 30 * d && abs(e.y - cy) < 30 * d) { host?.onAction(11); return true }
                if (abs(e.x - rx) < 30 * d && abs(e.y - cy) < 30 * d) { host?.onAction(10); return true }
            }
            if (mode == Mode.EXPANDED && media?.open != null &&
                e.x in (box.left + 20 * d)..(box.left + 82 * d) && e.y in (box.top + 20 * d)..(box.top + 82 * d)
            ) { host?.onAction(20); return true }
            if (mode == Mode.EXPANDED && abs(e.y - (box.top + 102 * d)) < 14 * d) {
                val x0 = box.left + 20 * d
                val x1 = box.right - 20 * d
                if (e.x in x0..x1) { host?.onSeek((e.x - x0) / (x1 - x0)); invalidate(); return true }
            }
            if (mode == Mode.EXPANDED) {
                val cy = box.top + 134 * d
                for (i in 0..2) {
                    val cx = width / 2f + (i - 1) * 78 * d
                    if (abs(e.x - cx) < 38 * d && abs(e.y - cy) < 26 * d) {
                        host?.onAction(i); invalidate(); return true
                    }
                }
            }
            if (mode == Mode.NOTIF && actionsOpen) {
                val n = notif?.actions?.size ?: 0
                for (i in 0 until n) {
                    chipRect(i, n, chip)
                    if (chip.contains(e.x, e.y)) { host?.onNotifAction(i); return true }
                }
            }
            host?.onTap(mode)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            host?.onLong(mode)
        }

        // deslizar para cima dispensa notificação / recolhe a ilha
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (vy < -900 && abs(vy) > abs(vx) && mode != Mode.IDLE && mode != Mode.COMPACT) {
                host?.onDismiss(mode); return true
            }
            if (vy > 900 && abs(vy) > abs(vx) && (mode == Mode.COMPACT || (mode == Mode.IDLE && media != null))) {
                host?.onTap(mode); return true
            }
            // pílula parada sem música: deslizar para baixo mostra de novo o último aviso
            if (vy > 900 && abs(vy) > abs(vx) && mode == Mode.IDLE && media == null) {
                host?.onExpandNotif(); return true
            }
            // deslizar para baixo na atividade ao vivo ou no timer: mostra o nome e o andamento
            if (vy > 900 && abs(vy) > abs(vx) && (mode == Mode.PROGRESS || mode == Mode.TIMER)) {
                host?.onExpandNotif(); return true
            }
            // deslizar para baixo no aviso abre os botões de ação
            if (vy > 900 && abs(vy) > abs(vx) && mode == Mode.NOTIF && notif?.actions?.isNotEmpty() == true) {
                host?.onExpandNotif(); return true
            }
            // deslizar para os lados: troca de faixa no player; dispensa avisos
            if (abs(vx) > 900 && abs(vx) > abs(vy)) {
                when (mode) {
                    Mode.EXPANDED -> { host?.onAction(if (vx < 0) 2 else 0); return true }
                    Mode.NOTIF, Mode.CHARGE, Mode.PROGRESS -> { host?.onDismiss(mode); return true }
                    else -> {}
                }
            }
            return false
        }
    })

    init {
        txt.fontFeatureSettings = "tnum"
        val t = target(Mode.IDLE)
        for (i in 0..2) { pos[i] = t[i]; tgt[i] = t[i] }
        w = t[0]; h = t[1]; r = t[2]
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { host?.onOutside(); return true }
        if (mode != Mode.EXPANDED) seeking = false
        else {
            val x0 = box.left + 20 * d
            val x1 = box.right - 20 * d
            fun frac() = ((e.x - x0) / (x1 - x0)).coerceIn(0f, 1f)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    if (abs(e.y - (box.top + 102 * d)) < 16 * d && e.x in x0..x1 &&
                        (media?.durationMs ?: 0L) > 0L
                    ) { seeking = true; seekFrac = frac(); invalidate(); return true }
                MotionEvent.ACTION_MOVE ->
                    if (seeking) { seekFrac = frac(); invalidate(); return true }
                MotionEvent.ACTION_UP ->
                    if (seeking) {
                        seeking = false; host?.onSeek(seekFrac); invalidate(); return true
                    }
                MotionEvent.ACTION_CANCEL ->
                    if (seeking) { seeking = false; invalidate(); return true }
            }
        }
        return gestures.onTouchEvent(e)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); kick()
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(frame)
        running = false
        super.onDetachedFromWindow()
    }

    /** Altura atual da pílula em px (a descida ao expandir acompanha isso). */
    fun heightNow(): Float = h

    fun applyIdleWidth(px: Float) {
        idleW = px
        setMode(mode, true)
    }

    /** Largura dos cartões (player/chamada; avisos e Siri são um pouco menores), ajustável no app. */
    private fun cardW(): Float =
        context.getSharedPreferences("ilha", Context.MODE_PRIVATE).getInt("cardw", 350).toFloat().coerceIn(280f, 380f)

    private fun twoLines(n: IslandBus.Notif?): Boolean {
        if (n == null || n.text.isEmpty()) return false
        txt.textSize = sp(13f); txt.typeface = tfNormal
        val maxW = cw(cardW() - 18f) - 88 * d - (if (queued > 0) 30 * d else 0f)
        return txt.measureText(n.text) > maxW
    }

    private fun target(m: Mode): FloatArray = when (m) {
        Mode.IDLE -> floatArrayOf(idleW, 34 * d, 17 * d)
        Mode.COMPACT, Mode.CHARGE, Mode.TIMER, Mode.INCALL, Mode.PROGRESS -> floatArrayOf(idleW + 92 * d, 36 * d, 18 * d)
        Mode.EXPANDED -> floatArrayOf(cw(cardW()), 160 * d, 44 * d)
        Mode.NOTIF -> {
            nTwo = twoLines(notif)
            floatArrayOf(cw(cardW() - 18f), ((if (actionsOpen) 116 else 76) + (if (nTwo) 16 else 0)) * d, 38 * d)
        }
        Mode.SIRI -> floatArrayOf(cw(cardW() - 50f), 66 * d, 33 * d)
        Mode.CALL -> floatArrayOf(cw(cardW()), 88 * d, 44 * d)
    }

    /** Texto para leitores de tela (TalkBack) acompanhar o que a ilha mostra. */
    private fun describe() {
        contentDescription = when (mode) {
            Mode.IDLE -> "Ilha Dinâmica"
            Mode.COMPACT, Mode.EXPANDED -> "Tocando: ${media?.title ?: ""} ${media?.artist ?: ""}".trim()
            Mode.NOTIF -> "${notif?.app ?: ""}: ${notif?.title ?: ""}. ${notif?.text ?: ""}".trim()
            Mode.SIRI -> "Assistente: pesquisar ou perguntar"
            Mode.CHARGE -> if (batteryLow) "Bateria fraca, $battery%" else "Carregando, $battery%"
            Mode.TIMER -> (if (timerPaused) "Timer pausado" else "Timer em andamento") +
                (if (timerLabel.isNotEmpty()) ": $timerLabel" else "") + ", faltam ${clock(timerLeftNow())}"
            Mode.CALL -> "Chamada recebida de ${call?.name ?: ""}"
            Mode.INCALL -> "Em chamada"
            Mode.PROGRESS -> "${live?.title ?: ""}: ${((live?.frac ?: 0f) * 100).toInt()}%"
        }
    }

    /** Respeita "Remover animações" do sistema: sem mola, a ilha muda de tamanho na hora. */
    private fun reduceMotion() = try {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    } catch (e: Exception) { false }

    fun setMode(m: Mode, force: Boolean = false) {
        describe()
        if (m != mode) {
            mode = m; age = 0f; content = 0f
            pad = if (m == Mode.SIRI) padBig else padSmall
            host?.onFrame((w + 2 * pad).toInt(), (h + 2 * pad).toInt())
        }
        else if (!force) { kick(); invalidate(); return }
        val t = target(m)
        for (i in 0..2) tgt[i] = t[i]
        if (reduceMotion()) {
            for (i in 0..2) { pos[i] = t[i]; vel[i] = 0f }
            w = pos[0]; h = pos[1]; r = pos[2]; age = 1f; content = 1f
            host?.onFrame((w + 2 * pad).toInt(), (h + 2 * pad).toInt())
            invalidate()
        }
        kick()
    }

    private fun kick() {
        if (!running && isAttachedToWindow) {
            running = true; last = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun needsLoop() =
        mode == Mode.SIRI || (mode == Mode.TIMER && !timerPaused) || mode == Mode.INCALL || mode == Mode.CHARGE || mode == Mode.CALL || ((mode == Mode.COMPACT || mode == Mode.EXPANDED) && media?.playing == true) ||
        (mode == Mode.EXPANDED && timerEnd > 0L && !timerPaused)

    private fun step(ts: Long) {
        if (!isAttachedToWindow) { running = false; return }
        val dt = if (last == 0L) 1f / 60f else ((ts - last) / 1_000_000_000f).coerceIn(0.001f, 1f / 30f)
        last = ts
        phase = (phase + dt / 2.4f) % 1f
        age += dt
        content = ((age - 0.06f) / 0.22f).coerceIn(0f, 1f)

        var settled = true
        val sub = dt / 4f
        for (i in 0..2) {
            repeat(4) {
                val acc = -STIFF * (pos[i] - tgt[i]) - DAMP * vel[i]
                vel[i] += acc * sub
                pos[i] += vel[i] * sub
            }
            if (abs(pos[i] - tgt[i]) < 0.4f && abs(vel[i]) < 4f) { pos[i] = tgt[i]; vel[i] = 0f }
            else settled = false
        }
        w = pos[0]; h = pos[1]; r = pos[2]

        val iw = (w + 2 * pad).toInt()
        val ih = (h + 2 * pad).toInt()
        if (iw != lastW || ih != lastH) { lastW = iw; lastH = ih; host?.onFrame(iw, ih) }
        invalidate()

        if (!settled || content < 1f || mode == Mode.SIRI)
            Choreographer.getInstance().postFrameCallback(frame)
        else if (needsLoop())
            // só equalizador/contagem rodando: ~30 quadros/s bastam e poupam bateria
            Choreographer.getInstance().postFrameCallbackDelayed(frame, 20)
        else { running = false; last = 0L }
    }

    private fun chipRect(i: Int, n: Int, out: RectF) {
        val gap = 8 * d
        val l = box.left + 16 * d
        val r = box.right - 16 * d
        val cw = (r - l - gap * (n - 1)) / n
        val x = l + i * (cw + gap)
        val off = if (nTwo) 16 * d else 0f   // mensagem em 2 linhas: botões descem junto
        out.set(x, box.top + 80 * d + off, x + cw, box.top + 110 * d + off)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt().coerceAtLeast(0)
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    // ---------------------------------------------------------------- desenho

    override fun onDraw(c: Canvas) {
        try { drawAll(c) } catch (e: Exception) { ErrorLog.add(context, "desenho/$mode", e) }
    }

    private fun drawAll(c: Canvas) {
        val l = (width - w) / 2f
        val t = pad.toFloat()
        box.set(l, t, l + w, t + h)
        rr = min(r, min(w, h) / 2f).coerceAtLeast(0f)
        val a = (content * 255).toInt()

        if (mode == Mode.SIRI) drawGlow(c, a)
        c.drawRoundRect(box, rr, rr, body)
        mat.setScale(1f, h); mat.postTranslate(0f, t); edgeShader.setLocalMatrix(mat)
        c.drawRoundRect(box, rr, rr, edge)

        c.save()
        clip.reset(); clip.addRoundRect(box, rr, rr, Path.Direction.CW); c.clipPath(clip)
        val sc = 0.9f + 0.1f * content   // conteúdo "cresce" ao aparecer, como no iOS
        c.scale(sc, sc, box.centerX(), box.centerY())
        c.translate(0f, (1f - content) * 8 * d)   // sobe levemente ao aparecer
        when (mode) {
            Mode.COMPACT -> drawCompact(c, a)
            Mode.EXPANDED -> drawExpanded(c, a)
            Mode.NOTIF -> drawNotif(c, a)
            Mode.SIRI -> drawSiri(c, a)
            Mode.CHARGE -> drawCharge(c, a)
            Mode.TIMER -> drawTimer(c, a)
            Mode.INCALL -> drawInCall(c, a)
            Mode.PROGRESS -> drawLive(c, a)
            Mode.CALL -> drawCall(c, a)
            Mode.IDLE -> {}
        }
        c.restore()
    }

    private fun drawGlow(c: Canvas, a: Int) {
        mat.setRotate(phase * 360f); mat.postTranslate(box.centerX(), box.centerY())
        sweepGlow.setLocalMatrix(mat)
        glow.shader = sweepGlow; glow.alpha = (a * 0.85f).toInt()
        c.drawRoundRect(box, rr, rr, glow)
        ring.shader = sweepGlow; ring.alpha = a
        c.drawRoundRect(box, rr, rr, ring)
    }

    private fun drawCompact(c: Canvas, a: Int) {
        val m = media ?: return
        val s = h - 10 * d
        if (m.durationMs > 0) {
            // fio de progresso bem fino na base da pílula, na cor da capa
            val f = (m.position(SystemClock.elapsedRealtime()).toFloat() / m.durationMs).coerceIn(0f, 1f)
            fill.shader = null; fill.color = m.accent; fill.alpha = (a * 0.55f).toInt()
            c.drawRect(box.left, box.bottom - 2 * d, box.left + box.width() * f, box.bottom, fill)
        }
        drawArt(c, box.left + 6 * d, box.centerY() - s / 2, s, 8 * d, a)
        if (timerEnd > 0L) {
            // música + timer ao mesmo tempo: contagem laranja no lugar do equalizador
            val left = timerLeftNow()
            val s2 = clock(left)
            val sz2 = if (left >= 3_600_000L) 10f else 12f
            txt.textSize = sp(sz2)
            val tw = txt.measureText(s2)
            text(c, s2, box.right - 10 * d - tw, box.centerY() + 4.5f * d, sz2, ORANGE, tw + 4 * d, a, true)
        } else {
            drawEq(c, box.right - 16 * d, box.centerY(), m.accent, 13 * d, m.playing, a)
        }
        // música tocando + download/atividade ao vivo: fio azul fino no topo mostra o progresso
        live?.let {
            fill.shader = null; fill.color = CYAN; fill.alpha = (a * 0.8f).toInt()
            c.drawRect(box.left, box.top, box.left + box.width() * it.frac, box.top + 2 * d, fill)
        }
    }

    private fun drawTint(c: Canvas, accent: Int, a: Int) {
        var sh = tintShader
        if (sh == null || tintColor != accent) {
            tintColor = accent
            val rd = Color.red(accent); val gr = Color.green(accent); val bl = Color.blue(accent)
            sh = RadialGradient(
                0f, 0f, 1f, Color.argb(75, rd, gr, bl), Color.argb(0, rd, gr, bl), Shader.TileMode.CLAMP
            )
            tintShader = sh
        }
        val rad = box.width() * 0.75f
        mat.setScale(rad, rad); mat.postTranslate(box.left + 40 * d, box.top + 30 * d)
        val g = tintShader ?: return
        g.setLocalMatrix(mat)
        tintPaint.shader = g; tintPaint.alpha = (a * tintK).toInt().coerceIn(0, 255)
        c.drawRect(box, tintPaint)
    }

    private fun drawCharge(c: Canvas, a: Int) {
        val col = if (batteryLow) RED else GREEN
        if (tintNotif) drawTint(c, col, a)
        val cy = box.centerY()
        val s = 10 * d
        val cx = box.left + 24 * d
        icon.reset()
        icon.moveTo(cx + 0.2f * s, cy - s); icon.lineTo(cx - 0.55f * s, cy + 0.1f * s)
        icon.lineTo(cx - 0.05f * s, cy + 0.1f * s); icon.lineTo(cx - 0.2f * s, cy + s)
        icon.lineTo(cx + 0.55f * s, cy - 0.15f * s); icon.lineTo(cx + 0.05f * s, cy - 0.15f * s)
        icon.close()
        fill.shader = null; fill.color = col; fill.alpha = a
        val pulse = 1f + 0.12f * sin(TAU * phase * 2)   // raio pulsa
        c.save(); c.scale(pulse, pulse, cx, cy); c.drawPath(icon, fill); c.restore()
        val s2 = "$battery%"
        txt.textSize = sp(15f)
        val tw = txt.measureText(s2)
        text(c, s2, box.right - 18 * d - tw, cy + 5.5f * d, 15f, col, tw + 4 * d, a, true)
    }

    private fun drawInCall(c: Canvas, a: Int) {
        if (tintNotif) drawTint(c, GREEN, a)
        val secs = ((SystemClock.elapsedRealtime() - activeStart) / 1000).coerceAtLeast(0L).toInt()
        val cy = box.centerY()
        val cx = box.left + 24 * d
        fill.shader = null; fill.color = GREEN; fill.alpha = a
        c.save()
        c.rotate(-45f, cx, cy)
        c.drawRoundRect(cx - 2.2f * d, cy - 7.5f * d, cx + 2.2f * d, cy + 7.5f * d, 2 * d, 2 * d, fill)
        c.drawCircle(cx, cy - 7.5f * d, 3.4f * d, fill)
        c.drawCircle(cx, cy + 7.5f * d, 3.4f * d, fill)
        c.restore()
        val s = "${secs / 60}:${(secs % 60).toString().padStart(2, '0')}"
        txt.textSize = sp(15f)
        val tw = txt.measureText(s)
        text(c, s, box.right - 18 * d - tw, cy + 5.5f * d, 15f, GREEN, tw + 4 * d, a, true)
    }

    /** Atividade ao vivo: ícone do app à esquerda e anel de progresso com a porcentagem à direita. */
    private fun drawLive(c: Canvas, a: Int) {
        val l = live ?: return
        val cy = box.centerY()
        val s = h - 14 * d
        artRect.set(box.left + 12 * d, cy - s / 2, box.left + 12 * d + s, cy + s / 2)
        val dr = l.icon
        if (dr != null) {
            c.save()
            artPath.reset(); artPath.addRoundRect(artRect, 6 * d, 6 * d, Path.Direction.CW); c.clipPath(artPath)
            dr.setBounds(artRect.left.toInt(), artRect.top.toInt(), artRect.right.toInt(), artRect.bottom.toInt())
            dr.alpha = a
            dr.draw(c)
            c.restore()
        }
        val cx = box.right - 24 * d
        val rad = 10.5f * d
        arcP.color = CYAN; arcP.alpha = a / 4
        c.drawCircle(cx, cy, rad, arcP)
        arcP.alpha = a
        arc.set(cx - rad, cy - rad, cx + rad, cy + rad)
        c.drawArc(arc, -90f, 360f * l.frac, false, arcP)
        val p = "${(l.frac * 100).toInt()}"
        txt.textSize = sp(9f)
        txt.typeface = tfStrong
        val tw = txt.measureText(p)
        text(c, p, cx - tw / 2f, cy + 3.2f * d, 9f, WHITE, tw + 4 * d, a, true)
    }

    private fun drawTimer(c: Canvas, a: Int) {
        val left = timerLeftNow()
        // últimos 10 s: tudo fica vermelho e os números pulsam, como contagem final
        val hot = !timerPaused && left in 1L..10_000L
        val tcol = if (timerPaused) GRAY else if (hot) RED else ORANGE   // pausado = cinza
        if (tintNotif && !timerPaused) drawTint(c, if (hot) RED else ORANGE, a)
        val cy = box.centerY()
        val cx = box.left + 24 * d
        val rad = 9 * d
        arcP.color = tcol; arcP.alpha = a / 4
        c.drawCircle(cx, cy, rad, arcP)
        arcP.alpha = a
        arc.set(cx - rad, cy - rad, cx + rad, cy + rad)
        c.drawArc(arc, -90f, 360f * left / timerTotal.coerceAtLeast(1L), false, arcP)
        val s = clock(left)
        val sz = if (left >= 3_600_000L) 12f else 15f   // com horas o texto é maior: reduz para não encostar na câmera
        txt.textSize = sp(sz)
        val tw = txt.measureText(s)
        val ta = if (hot) (a * (0.6f + 0.4f * abs(sin(TAU * phase * 2)))).toInt() else a
        text(c, s, box.right - 18 * d - tw, cy + (if (sz < 15f) 4.5f else 5.5f) * d, sz, tcol, tw + 4 * d, ta, true)
    }

    private fun drawCall(c: Canvas, a: Int) {
        val n = call ?: return
        val cy = box.centerY()
        val s = 48 * d
        val x0 = box.left + 16 * d
        artRect.set(x0, cy - s / 2, x0 + s, cy + s / 2)
        val dr = n.icon
        if (dr != null) {
            c.save()
            artPath.reset(); artPath.addOval(artRect, Path.Direction.CW); c.clipPath(artPath)
            dr.setBounds(artRect.left.toInt(), artRect.top.toInt(), artRect.right.toInt(), artRect.bottom.toInt())
            dr.alpha = a
            dr.draw(c)
            c.restore()
        } else {
            fill.shader = null; fill.color = Color.rgb(58, 58, 60); fill.alpha = a
            c.drawOval(artRect, fill)
        }
        val gx = box.right - 38 * d
        val rx = gx - 56 * d
        val tx = x0 + s + 12 * d
        val maxW = rx - 26 * d - tx
        text(c, n.name, tx, cy - 3 * d, 16f, WHITE, maxW, a, true)
        text(c, n.sub, tx, cy + 17 * d, 13f, GRAY, maxW, a)
        fill.shader = null
        fill.color = RED; fill.alpha = a; c.drawCircle(rx, cy, 22 * d, fill)
        // anel que se expande atrás do botão de atender
        val ringT = (phase * 2) % 1f
        arcP.color = GREEN; arcP.alpha = ((1f - ringT) * a * 0.6f).toInt()
        c.drawCircle(gx, cy, 22 * d + ringT * 9 * d, arcP)
        fill.color = GREEN; fill.alpha = a; c.drawCircle(gx, cy, 22 * d, fill)
        glyph.alpha = a
        c.drawLine(rx - 7 * d, cy - 7 * d, rx + 7 * d, cy + 7 * d, glyph)
        c.drawLine(rx - 7 * d, cy + 7 * d, rx + 7 * d, cy - 7 * d, glyph)
        c.drawLine(gx - 7 * d, cy + 0.5f * d, gx - 2 * d, cy + 5.5f * d, glyph)
        c.drawLine(gx - 2 * d, cy + 5.5f * d, gx + 7 * d, cy - 5 * d, glyph)
    }

    private fun drawExpanded(c: Canvas, a: Int) {
        val m = media ?: return
        drawTint(c, m.accent, a)
        val x0 = box.left + 20 * d
        val y0 = box.top + 20 * d
        drawArt(c, x0, y0, 62 * d, 14 * d, a)
        val tx = x0 + 62 * d + 14 * d
        val maxW = box.right - 52 * d - tx
        text(c, m.title, tx, y0 + 26 * d, 17f, WHITE, maxW, a, true)
        text(c, m.artist, tx, y0 + 48 * d, 14f, GRAY, maxW, a)
        drawEq(c, box.right - 24 * d, y0 + 14 * d, m.accent, 16 * d, m.playing, a)

        val trackR = box.right - 20 * d
        val py = box.top + 102 * d
        fill.shader = null; fill.color = WHITE; fill.alpha = a / 5
        c.drawRoundRect(x0, py - 2 * d, trackR, py + 2 * d, 2 * d, 2 * d, fill)
        if (m.durationMs > 0) {
            val f = if (seeking) seekFrac
                else (m.position(SystemClock.elapsedRealtime()).toFloat() / m.durationMs).coerceIn(0f, 1f)
            fill.color = WHITE; fill.alpha = (a * 0.9f).toInt()
            c.drawRoundRect(x0, py - 2 * d, x0 + (trackR - x0) * f, py + 2 * d, 2 * d, 2 * d, fill)
            fill.alpha = a
            c.drawCircle(x0 + (trackR - x0) * f, py, 4.5f * d, fill)
            val cur = fmt(if (seeking) (seekFrac * m.durationMs).toLong() else m.position(SystemClock.elapsedRealtime()))
            text(c, cur, x0, py + 16 * d, 11f, GRAY, 60 * d, a)
            val tot = fmt(m.durationMs)
            txt.textSize = sp(11f)
            val tw = txt.measureText(tot)
            text(c, tot, trackR - tw, py + 16 * d, 11f, GRAY, tw + 4 * d, a)
        }

        // timer rodando junto com a música: nome e tempo no centro, entre o tempo decorrido e o total
        if (timerEnd > 0L) {
            val ts = (if (timerLabel.isNotEmpty()) timerLabel else "Timer") + " • " + clock(timerLeftNow()) + (if (timerPaused) " (pausado)" else "")
            txt.textSize = sp(11f); txt.typeface = tfStrong
            val tw2 = min(txt.measureText(ts), 140 * d)
            text(c, ts, box.centerX() - tw2 / 2, py + 16 * d, 11f, if (timerPaused) GRAY else ORANGE, tw2 + 4 * d, a, true)
        }

        val cy = box.top + 134 * d
        val cx = box.centerX()
        fill.color = WHITE; fill.alpha = a
        drawPrev(c, cx - 78 * d, cy, 9 * d)
        if (m.playing) drawPause(c, cx, cy, 13 * d) else drawPlay(c, cx, cy, 13 * d)
        drawNext(c, cx + 78 * d, cy, 9 * d)
    }

    private fun drawNotif(c: Canvas, a: Int) {
        val n = notif ?: return
        if (tintNotif && n.accent != 0) drawTint(c, n.accent, a)
        val s = 44 * d
        val x0 = box.left + 16 * d
        val cy = box.top + 38 * d   // linha de cima fixa, mesmo com os botões abertos
        n.icon?.let { dr ->
            c.save()
            artRect.set(x0, cy - s / 2, x0 + s, cy + s / 2)
            val rad = if (n.round) s / 2 else 11 * d
            artPath.reset(); artPath.addRoundRect(artRect, rad, rad, Path.Direction.CW)
            c.clipPath(artPath)
            dr.setBounds(artRect.left.toInt(), artRect.top.toInt(), artRect.right.toInt(), artRect.bottom.toInt())
            dr.alpha = a
            dr.draw(c)
            c.restore()
        }
        val tx = x0 + s + 12 * d
        val maxW = box.right - 16 * d - tx - (if (queued > 0) 30 * d else 0f)
        val head = if (n.count > 1) "${n.title} (${n.count})" else n.title
        text(c, head, tx, cy - 3 * d, 15f, WHITE, maxW, a, true)
        val msg = n.text.ifEmpty { n.app }
        if (nTwo && n.text.isNotEmpty()) {
            // mensagem longa: quebra em 2 linhas (na última palavra que cabe na primeira)
            txt.textSize = sp(13f); txt.typeface = tfNormal
            val cut = txt.breakText(msg, true, maxW, null)
            val brk = msg.lastIndexOf(' ', cut - 1)
            val at = if (brk > cut / 2) brk else cut
            text(c, msg.substring(0, at).trimEnd(), tx, cy + 16 * d, 13f, GRAY, maxW, a)
            text(c, msg.substring(at).trimStart(), tx, cy + 32 * d, 13f, GRAY, maxW, a)
        } else text(c, msg, tx, cy + 16 * d, 13f, GRAY, maxW, a)
        if (queued > 0) {
            val b = "+$queued"
            txt.textSize = sp(12f)
            val bw = txt.measureText(b)
            text(c, b, box.right - 16 * d - bw, cy - 3 * d, 12f, CYAN, bw + 4 * d, a, true)
        }
        val acts = n.actions
        if (actionsOpen && acts.isNotEmpty()) {
            for (i in acts.indices) {
                chipRect(i, acts.size, chip)
                fill.shader = null; fill.color = Color.rgb(58, 58, 60); fill.alpha = a
                c.drawRoundRect(chip, chip.height() / 2, chip.height() / 2, fill)
                val fs = if (acts.size >= 3) 12f else 13f   // com 3 botões o texto fica um pouco menor
                val col = if (acts[i].mutePkg != null) GRAY else WHITE
                txt.textSize = sp(fs)
                val tw = min(txt.measureText(acts[i].label), chip.width() - 12 * d)
                text(c, acts[i].label, chip.centerX() - tw / 2, chip.centerY() + 5 * d, fs, col, chip.width() - 12 * d, a, true)
            }
        } else if (acts.isNotEmpty()) {
            // seta discreta: há ações (deslize para baixo)
            glyph.alpha = a / 2
            val gx = box.centerX()
            val gy = box.bottom - 9 * d
            c.drawLine(gx - 5 * d, gy - 2 * d, gx, gy + 2 * d, glyph)
            c.drawLine(gx, gy + 2 * d, gx + 5 * d, gy - 2 * d, glyph)
        }
    }

    private fun drawSiri(c: Canvas, a: Int) {
        val ox = box.left + 38 * d
        val oy = box.centerY()
        val orr = 15 * d
        mat.setRotate(phase * 360f); mat.postTranslate(ox, oy); sweepOrbA.setLocalMatrix(mat)
        fill.shader = sweepOrbA; fill.alpha = a
        c.drawCircle(ox, oy, orr, fill)
        mat.setRotate(-phase * 720f); mat.postTranslate(ox, oy); sweepOrbB.setLocalMatrix(mat)
        fill.shader = sweepOrbB; fill.alpha = (a * 0.55f).toInt()
        c.drawCircle(ox + 2 * d, oy - 1 * d, orr * 0.72f, fill)
        fill.shader = null

        val tx = ox + orr + 16 * d
        val label = "Pesquisar ou perguntar"
        text(c, label, tx, oy + 5.5f * d, 16f, Color.argb(230, 255, 255, 255), box.right - tx, a, true)
        val cursorX = tx + txt.measureText(label) + 5 * d
        val blink = if ((phase * 4).toInt() % 2 == 0) a else a / 5
        fill.color = CYAN; fill.alpha = blink
        if (cursorX < box.right - 12 * d)
            c.drawRoundRect(cursorX, oy - 10 * d, cursorX + 2.2f * d, oy + 10 * d, d, d, fill)
    }

    // ---------------------------------------------------------------- helpers

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        maxW: Float, a: Int, strong: Boolean = false
    ) {
        txt.textSize = sp(size)
        txt.typeface = if (strong) tfStrong else tfNormal
        txt.color = color
        txt.alpha = Color.alpha(color) * a / 255
        val out = TextUtils.ellipsize(s, txt, maxOf(maxW, 0f), TextUtils.TruncateAt.END).toString()
        c.drawText(out, x, y, txt)
    }

    private fun drawArt(c: Canvas, x: Float, y: Float, size: Float, rad: Float, a: Int) {
        artRect.set(x, y, x + size, y + size)
        c.save()
        artPath.reset(); artPath.addRoundRect(artRect, rad, rad, Path.Direction.CW)
        c.clipPath(artPath)
        fill.shader = null
        val bmp = media?.art
        if (bmp != null) {
            fill.alpha = a
            c.drawBitmap(bmp, null, artRect, fill)
        } else {
            fill.color = Color.rgb(58, 58, 60); fill.alpha = a
            c.drawRect(artRect, fill)
            txt.textSize = size * 0.5f; txt.color = GRAY; txt.alpha = a
            c.drawText("♪", x + size * 0.3f, y + size * 0.68f, txt)
        }
        c.restore()
    }

    private fun drawEq(c: Canvas, right: Float, cy: Float, color: Int, maxH: Float, playing: Boolean, a: Int) {
        val bw = 3 * d; val gap = 2.5f * d
        val x0 = right - (4 * bw + 3 * gap)
        fill.shader = null; fill.color = color; fill.alpha = a
        for (i in 0..3) {
            val f = if (playing) 0.3f + 0.7f * abs(sin(TAU * phase * (i + 1) + i * 1.7f)) else 0.2f
            val bh = maxH * f
            val x = x0 + i * (bw + gap)
            c.drawRoundRect(x, cy - bh / 2, x + bw, cy + bh / 2, bw / 2, bw / 2, fill)
        }
    }

    private fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        icon.moveTo(x1, y1); icon.lineTo(x2, y2); icon.lineTo(x3, y3); icon.close()
    }

    private fun drawPrev(c: Canvas, cx: Float, cy: Float, s: Float) {
        icon.reset()
        tri(cx, cy - s, cx - s, cy, cx, cy + s)
        tri(cx + s, cy - s, cx, cy, cx + s, cy + s)
        c.drawPath(icon, fill)
    }

    private fun drawNext(c: Canvas, cx: Float, cy: Float, s: Float) {
        icon.reset()
        tri(cx - s, cy - s, cx, cy, cx - s, cy + s)
        tri(cx, cy - s, cx + s, cy, cx, cy + s)
        c.drawPath(icon, fill)
    }

    private fun drawPlay(c: Canvas, cx: Float, cy: Float, s: Float) {
        icon.reset()
        tri(cx - s * 0.75f, cy - s, cx + s, cy, cx - s * 0.75f, cy + s)
        c.drawPath(icon, fill)
    }

    private fun drawPause(c: Canvas, cx: Float, cy: Float, s: Float) {
        c.drawRoundRect(cx - s * 0.8f, cy - s, cx - s * 0.2f, cy + s, 2 * d, 2 * d, fill)
        c.drawRoundRect(cx + s * 0.2f, cy - s, cx + s * 0.8f, cy + s, 2 * d, 2 * d, fill)
    }
}
