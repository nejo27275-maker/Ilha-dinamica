package br.neto.ilha

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.os.Build
import android.os.SystemClock
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Vigia: a cada ~15 min religa a ilha se o usuário a quer ligada e o sistema a matou. */
class Watchdog : JobService() {
    override fun onStartJob(p: JobParameters?): Boolean {
        revive(this)
        return false
    }

    override fun onStopJob(p: JobParameters?) = true

    companion object {
        /** A ilha deve estar ligada? Só deixa de ser "sim" quando o usuário aperta Desligar (botão do app ou das Configurações rápidas). */
        fun want(c: Context): Boolean {
            val p = c.getSharedPreferences("ilha", Context.MODE_PRIVATE)
            return p.getBoolean("want", false) && !p.getBoolean("userOff", false)
        }

        /** O usuário desligou de propósito? (impede religar sozinha, inclusive depois de reiniciar o celular). */
        fun userOff(c: Context) = c.getSharedPreferences("ilha", Context.MODE_PRIVATE).getBoolean("userOff", false)

        fun setWant(c: Context, on: Boolean) {
            c.getSharedPreferences("ilha", Context.MODE_PRIVATE).edit()
                .putBoolean("want", on).putBoolean("userOff", !on).apply()
            if (!on) { IslandService.cancelAlarm(c); KeepAlive.cancel(c) }   // desligada de propósito: nada pode religá-la
            else KeepAlive.arm(c)
        }

        fun revive(c: Context) {
            try {
                if (want(c) && !IslandService.running && Settings.canDrawOverlays(c))
                    c.startForegroundService(Intent(c, IslandService::class.java))
            } catch (e: Exception) { ErrorLog.add(c, "Watchdog", e) }
        }

        fun schedule(c: Context) {
            try {
                val js = c.getSystemService(JobScheduler::class.java)
                if (js.getPendingJob(77) != null) return
                js.schedule(
                    JobInfo.Builder(77, ComponentName(c, Watchdog::class.java))
                        .setPeriodic(15 * 60 * 1000L)
                        .setPersisted(true)
                        .build()
                )
            } catch (e: Exception) { ErrorLog.add(c, "Watchdog", e) }
        }
    }
}

/**
 * Guarda-costas: a cada ~5 min (e 1,5 s depois de o sistema derrubar a ilha ou de você fechá-la nos apps recentes)
 * confere se ela deve estar ligada e religa. Só para quando o usuário aperta Desligar.
 */
class KeepAlive : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Watchdog.want(c)) return
        Watchdog.revive(c)
        arm(c)   // agenda a próxima conferência
    }

    companion object {
        private const val EVERY = 5 * 60_000L

        private fun pi(c: Context): PendingIntent =
            PendingIntent.getBroadcast(
                c, 10, Intent(c, KeepAlive::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        fun arm(c: Context, inMs: Long = EVERY) {
            try {
                val am = c.getSystemService(AlarmManager::class.java) ?: return
                val at = SystemClock.elapsedRealtime() + inMs
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                    am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi(c))
                else am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi(c))
            } catch (e: Exception) { ErrorLog.add(c, "KeepAlive", e) }
        }

        fun cancel(c: Context) {
            try { c.getSystemService(AlarmManager::class.java)?.cancel(pi(c)) } catch (e: Exception) {}
        }
    }
}
