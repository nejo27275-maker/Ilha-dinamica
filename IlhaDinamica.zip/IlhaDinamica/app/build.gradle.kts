plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.neto.ilha"
    compileSdk = 34
    defaultConfig {
        applicationId = "br.neto.ilha"
        minSdk = 28
        targetSdk = 34
        versionCode = 79
        versionName = "6.28"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// Zero dependências externas: só o SDK do Android.
